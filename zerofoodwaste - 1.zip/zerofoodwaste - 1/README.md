# ZeroWaste - AI-Powered Food Donation & Rescue Platform

**A frontend-only food rescue network built with nothing but HTML5, CSS3 and vanilla JavaScript.**

ZeroWaste connects restaurants, hotels, caterers, canteens, event organisers and households that have
surplus food with NGOs, shelters, community kitchens and volunteers who need it - before the food
becomes waste.

> **This is a demonstration project.** There is no backend, no database and no real authentication.
> Everything runs in your browser and is stored in `localStorage`. The "AI" features are transparent
> rule-based helpers, not a trained model. See [What is simulated](#what-is-simulated).

---

## 1. How to run it

No build step, no server, no dependencies to install.

**Option A - just open it**

1. Download or copy the project folder.
2. Double-click `index.html` (or drag it into a browser).

**Option B - run a tiny local server (recommended)**

Some browsers restrict `localStorage` on `file://` URLs. To be safe, serve the folder:

```bash
# Python 3 (usually already installed)
python -m http.server 5500

# or Node.js
npx serve .
```

Then open <http://localhost:5500>.

**Option C - VS Code**

Install the *Live Server* extension, right-click `index.html` and choose **Open with Live Server**.

**Demo accounts** (also one-click fillable on the login page):

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@zerowaste.org` | `admin123` |
| Restaurant donor | `donor@spicegarden.com` | `donor123` |
| Household donor | `ananya@home.com` | `home123` |
| NGO / receiver | `ngo@helpinghands.org` | `ngo123` |
| Pending receiver | `rahul@volunteer.in` | `volunteer123` |

> The last account is **Pending Verification** on purpose: signing in with it shows the message a
> receiver sees before an admin approves them. Approve it in the **Admin console** first.

---

## 2. Folder structure

```
zerofoodwaste/
|
|-- index.html          # Home: hero, stats, how it works, featured donations, impact, FAQ
|-- donate.html         # Food donation form (validation, image preview, live estimates)
|-- receive.html        # Browse available food (search, filters, sorting, request modal)
|-- map.html            # Food donation map (Leaflet + OpenStreetMap, CSS pin fallback)
|-- login.html          # Login + forgot-password demo
|-- register.html       # Donor and Receiver/NGO registration tabs
|-- dashboard.html      # Donor / receiver dashboard (KPIs, charts, status flow, insights)
|-- admin.html          # Admin console (users, donations, requests tables + actions)
|-- about.html          # Problem, mission, vision, impact, honest simulation notes
|
|-- css/
|   `-- style.css       # One design system: tokens, components, dark mode, responsive rules
|
|-- js/
|   |-- app.js          # Core: storage, seed data, helpers, "AI" rules, header/footer, cards
|   |-- auth.js         # Simulated login, registration, sessions, password meter
|   |-- donations.js    # Donate page: validation, estimates, image preview, persistence
|   |-- receive.js      # Receive page: filtering, sorting, request modal, deep links
|   |-- map.js          # Map page: Leaflet map, markers, filters, offline CSS fallback
|   |-- dashboard.js    # Dashboard: KPIs, charts, status flow, insights, history
|   `-- admin.js        # Admin: stats, tables, approve/reject/complete/delete actions
|
|-- images/
|   |-- favicon.svg     # Browser tab icon
|   `-- logo.svg        # Standalone wordmark logo
|
`-- README.md
```

**Script load order matters.** Every page loads `js/app.js` first (it defines `window.ZW` and all the
shared helpers), then the page-specific module. Auth pages and the dashboard/admin load
`app.js -> auth.js -> page.js`.

---

## 3. Main features

**Home (`index.html`)**
- Responsive navbar with a mobile drawer, theme toggle and session-aware Login/Logout.
- Hero with call-to-action buttons, an animated "live donations" counter and a food image.
- Statistics strip that counts up when scrolled into view.
- *How It Works* (Donate -> Match -> Pickup -> Deliver), featured live donations, impact story,
  testimonials, FAQ accordion and a closing call to action.

**Donate Food (`donate.html`)**
- Full donation form: donor details, food type, diet category, quantity + unit, estimated servings,
  preparation/expiry dates, pickup deadline and address, description, image upload and donor type.
- JavaScript validation (required, email, phone, numeric, `min`, `match`, future dates).
- Live **estimated servings** calculated from quantity, unit, food type and diet.
- **Image preview** before submission, downscaled via `<canvas>` so it fits in storage.
- Expiry-date cross-check against the preparation date.
- Stored in `localStorage` and shown straight away under "Your donations".

**Receive Food (`receive.html`)**
- Search by food name, donor or city.
- Filters: city/location, diet (veg / non-veg / vegan), food type, distance radius, freshness, priority.
- Sorting: nearest, recently added, expiring soon, priority score, most servings.
- Donation cards with image, category, quantity, servings, distance, pickup deadline, donor type and
  status badge, plus a **Request Food** modal (name, organization, phone, servings, pickup preference).
- Requests are saved in `localStorage` and listed under "My requests".

**Food Map (`map.html`)**
- Real Leaflet + OpenStreetMap map loaded from CDN, with a coloured pin per donation.
- Click a pin for a popup; click a card to fly to that pin.
- Search + filters by food type, city, priority and distance, plus a "use my location" demo button.
- If Leaflet or the tiles cannot load (offline demo), it automatically falls back to a
  CSS/styled pin map so the page still works.

**Login / Register (`login.html`, `register.html`)**
- Login with email + password, "remember me", and a forgot-password modal that reveals the stored
  demo password instead of sending an email.
- Donor and Receiver/NGO registration in tabs, with duplicate-email checks.
- NGO / receiver accounts start as **Pending Verification** and can only sign in after an admin
  approves them.

**Dashboard (`dashboard.html`)**
- Donor KPIs: total, active and completed donations, food saved, meals provided.
- Receiver KPIs: available food, requests made, accepted requests, completed pickups.
- CSS/JS bar chart (last six months) and donut chart (status breakdown).
- Status-flow table where a donor can advance a donation through
  `Pending -> Accepted -> Pickup Scheduled -> Picked Up -> Delivered -> Completed`.
- Insights panel with a simulated smart match suggestion and an activity feed.
- Full history panel and a "Refresh data" button.

**Admin (`admin.html`)**
- Platform stats: users, donations, pending donations, completed donations, food rescued, active NGOs,
  pending verifications.
- Three tables (Users, Donations, Food requests) with a row filter.
- Actions: Approve, Reject, Advance status, Mark completed, Delete - all written back to
  `localStorage`.
- "Restore demo data" button to reset the whole dataset.

**Cross-cutting**
- Dark / light mode toggle, saved per browser.
- Toast notifications, modal dialogs, scroll-reveal animations, skeleton loading states and empty
  states.
- Keyboard-accessible skip link, focus states, `aria-*` attributes and respectful color contrast.
- Responsive from large desktop down to small mobile.

---

## 4. How localStorage works

There is no server, so the browser itself is the database. `js/app.js` wraps `localStorage` in a tiny
helper (`ZW.storeGet` / `ZW.storeSet`) with an in-memory fallback for browsers that block it
(private mode, some `file://` setups).

Every collection is stored under one key:

| Key | Contents |
|-----|----------|
| `zw_donations` | All food donations (seeded + anything you add) |
| `zw_requests` | All food requests made by receivers |
| `zw_users` | Registered accounts (donors, receivers, admin) |
| `zw_session`  | The currently signed-in user |
| `zw_theme`    | Chosen light / dark theme |
| `zw_activity` | Recent activity feed entries |
| `zw_user_location` | The receiver's "current location" |
| `zw_newsletter` | Newsletter signups from the footer |
| `zw_seed_version` | Which demo dataset version has been loaded |

How the data flows:

1. On first load, `ZW.seed()` writes the sample dataset and records the seed version.
2. Every page reads the same collections through `ZW.getDonations()`, `ZW.getRequests()`,
   `ZW.getUsers()`, etc.
3. Every change (a new donation, a request, an approval, a status update) is written straight back
   with the matching `save*` function.
4. Because it is all `localStorage`, **your changes survive a refresh and are visible on every page**.

Resetting: use **Restore demo data** on the Admin console, or clear the site's storage from your
browser's developer tools. Deleting the `zw_*` keys brings back a clean demo.

Bumping the `SEED_VERSION` string in `js/app.js` also forces a fresh dataset for everyone.

---

## 5. What is simulated

Be honest about this in a demo - it is a feature, not a gap:

| Feature | How it really works |
|---------|--------------------|
| **Login / registration** | Plain comparison against user objects in `localStorage`. Passwords are stored in clear text and are visible in DevTools. No hashing, no server, no real security. |
| **Sessions** | A `zw_session` object in storage. "Remember me" only controls the saved email. |
| **Food quantity estimation** | A rule of thumb: servings per unit depends on the food type, unit and diet. No machine learning. |
| **Freshness indicator** | The fraction of the safe window (preparation -> expiry) still remaining, shown as a percentage and a label. |
| **Rescue Priority Score** | A weighted sum: urgency (40) + volume (25) + perishability (20) + proximity (15), capped at 100 and labelled High / Medium / Low. |
| **Smart donor-receiver matching** | Scores how well a donation fits a request using servings coverage, pickup ability, distance, freshness and priority. |
| **Map** | Real coordinates on a real Leaflet/OpenStreetMap map, but straight-line (haversine) distances - not driving routes. |
| **Admin actions** | Approve / reject / delete simply rewrite browser storage. Nothing leaves the device. |
| **Email** | The newsletter form and forgot-password flow only write to `localStorage`. No email is sent. |

---

## 6. How a real backend could be connected later

The code was written so the storage layer is the only thing that would change:

1. **Swap the storage layer.** Replace `ZW.storeGet` / `ZW.storeSet` (and the `get*/save*` wrappers)
   in `js/app.js` with `fetch()` calls to a REST API backed by PostgreSQL or MongoDB. The rest of the
   app keeps calling the same functions.
2. **Real authentication.** Replace the login simulation in `js/auth.js` with an API call that returns
   a session token, store it in an httpOnly cookie, and hash passwords server-side (bcrypt/argon2).
3. **Server-side scoring.** Move `ZW.estimateServings`, `ZW.freshness`, `ZW.priority` and
   `ZW.matchScore` into the backend so every client sees the same ranking, and add a routing API for
   real travel distances instead of straight lines.
4. **Image hosting.** Upload photos to object storage (S3 / Cloudinary) and store the URL, rather than
   the downscaled data URL in `localStorage`.
5. **Notifications.** Add push / SMS / email alerts when food near a receiver is about to expire.
6. **Verification workflow.** Persist the admin Approve / Reject results as real account states with an
   audit log.
7. **Roles & security.** Enforce roles (donor / receiver / admin) on the server, add rate limiting and
   input validation on every endpoint.

Because the UI already talks in terms of donations, requests, users and statuses, the API can map
almost 1:1 onto the existing data shapes.

---

## 7. Accessibility & code quality

- Semantic HTML5 landmarks (`header`, `main`, `nav`, `section`, `footer`) and one `<h1>` per page.
- Skip-to-content link, visible focus rings and `aria-*` attributes on interactive widgets.
- Form errors announced with `aria-invalid` and inline messages next to the field.
- Colour contrast checked for the green/white palette in both light and dark themes.
- No frameworks, no build tools, no console errors, and no broken links.

---

## 8. Credits

- Design and code: ZeroWaste demo project.
- Icons: [Font Awesome](https://fontawesome.com/) (CDN).
- Font: [Poppins](https://fonts.google.com/specimen/Poppins) via Google Fonts.
- Photography: [Unsplash](https://unsplash.com/).
- Map tiles: [OpenStreetMap](https://www.openstreetmap.org/) via [Leaflet](https://leafletjs.com/).

Built as a portfolio / college demonstration project. Enjoy, and rescue some food.
