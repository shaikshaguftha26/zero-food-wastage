/* ==========================================================================
   ZeroWaste - admin.js
   Frontend-only admin console: platform statistics plus user, donation and
   food-request tables with Approve / Reject / Complete / Delete actions.
   Every action writes back to localStorage.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});
  var session = null;

  /* ------------------------------------------------------------- 1. HELPERS */
  function persist(kind, list) {
    if (kind === 'users') ZW.saveUsers(list);
    else if (kind === 'donations') ZW.saveDonations(list);
    else ZW.saveRequests(list);
  }

  function renderStats() {
    var users = ZW.getUsers();
    var donations = ZW.getDonations();
    var requests = ZW.getRequests();
    var completed = donations.filter(function (d) { return d.status === 'Completed'; });
    var delivered = donations.filter(function (d) {
      return d.status === 'Delivered' || d.status === 'Completed';
    });
    var meals = delivered.reduce(function (s, d) { return s + (Number(d.servings) || 0); }, 0);
    var ngos = users.filter(function (u) { return u.role === 'receiver'; }).length;
    var pendingUsers = users.filter(function (u) { return u.status === 'Pending Verification'; }).length;

    var cards = [
      ['fa-users', 'linear-gradient(135deg,#16a34a,#4ade80)', users.length, 'Total users', 'donors, NGOs and admins'],
      ['fa-hand-holding-heart', 'linear-gradient(135deg,#2563eb,#60a5fa)', donations.length, 'Total donations', 'all statuses'],
      ['fa-hourglass-half', 'linear-gradient(135deg,#d97706,#fbbf24)',
        donations.filter(function (d) { return d.status === 'Pending'; }).length, 'Pending donations', 'awaiting a receiver'],
      ['fa-circle-check', 'linear-gradient(135deg,#0f766e,#2dd4bf)', completed.length, 'Completed donations', 'end of the flow'],
      ['fa-utensils', 'linear-gradient(135deg,#7c3aed,#a78bfa)', meals, 'Food rescued', 'estimated servings'],
      ['fa-handshake-angle', 'linear-gradient(135deg,#0ea5e9,#38bdf8)', ngos, 'Active NGOs', 'receiver accounts'],
      ['fa-user-clock', 'linear-gradient(135deg,#dc2626,#f87171)', pendingUsers, 'Pending verifications', 'needs review']
    ];

    var host = ZW.byId('admin-kpis');
    if (!host) return;
    host.innerHTML = cards.map(function (c) {
      return '<div class="kpi"><div class="kpi-icon" style="background:' + c[1] + '">' +
        '<i class="fa-solid ' + c[0] + '"></i></div>' +
        '<div class="kpi-value">' + ZW.esc(c[2]) + '</div>' +
        '<div class="kpi-label">' + c[3] + '</div>' +
        '<div class="kpi-trend" style="color:var(--text-soft)">' + c[4] + '</div></div>';
    }).join('');
  }

  function actionBtns(cells) {
    return '<div class="table-actions">' + cells + '</div>';
  }

  /* ---------------------------------------------------------- 2. USER TABLE */
  function renderUsers() {
    var host = ZW.byId('admin-users');
    if (!host) return;
    var users = ZW.getUsers();
    if (!users.length) { host.innerHTML = ZW.emptyState('No users', 'No accounts match this filter.', ''); return; }

    var rows = users.map(function (u) {
      return '<tr data-user="' + ZW.esc(u.id) + '">' +
        '<td><strong>' + ZW.esc(u.name) + '</strong><br><small>' + ZW.esc(u.id) + '</small></td>' +
        '<td>' + ZW.esc(u.email) + '<br><small class="text-muted">' + ZW.esc(u.phone) + '</small></td>' +
        '<td><span class="badge badge-neutral">' + ZW.esc(u.role) + '</span></td>' +
        '<td>' + ZW.esc(u.org) + '<br><small class="text-muted">' + ZW.esc(u.city) + '</small></td>' +
        '<td>' + (u.status === 'Active'
          ? '<span class="badge badge-completed">Active</span>'
          : '<span class="badge badge-pending">' + ZW.esc(u.status) + '</span>') + '</td>' +
        '<td>' + ZW.esc(ZW.formatDate(u.joinedAt)) + '</td>' +
        '<td>' + actionBtns(
          (u.status !== 'Active'
            ? '<button type="button" class="btn btn-success" data-approve-user="' + ZW.esc(u.id) + '">' +
              '<i class="fa-solid fa-check"></i> Approve</button>'
            : '<button type="button" class="btn btn-warn" data-reject-user="' + ZW.esc(u.id) + '">' +
              '<i class="fa-solid fa-ban"></i> Revoke</button>') +
          '<button type="button" class="btn btn-danger" data-delete-user="' + ZW.esc(u.id) + '">' +
          '<i class="fa-solid fa-trash"></i> Delete</button>'
        ) + '</td>' +
      '</tr>';
    }).join('');

    host.innerHTML = table(['User', 'Contact', 'Role', 'Organisation', 'Status', 'Joined', 'Actions'], rows);
  }

  /* ------------------------------------------------------ 3. DONATION TABLE */
  function renderDonations() {
    var host = ZW.byId('admin-donations');
    if (!host) return;
    var donations = ZW.getDonations().slice().sort(function (a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
    if (!donations.length) { host.innerHTML = ZW.emptyState('No donations', 'Nothing has been listed yet.', ''); return; }

    var rows = donations.map(function (d) {
      var last = ZW.STATUS_FLOW[ZW.STATUS_FLOW.length - 1];
      return '<tr>' +
        '<td><strong>' + ZW.esc(d.id) + '</strong><br><small>' + ZW.esc(ZW.timeAgo(d.createdAt)) + '</small></td>' +
        '<td>' + ZW.esc(d.foodName) + '<br><small class="text-muted">' + ZW.esc(d.foodType) + ' - ' +
          ZW.esc(ZW.CATEGORY_LABEL[d.category] || d.category) + '</small></td>' +
        '<td>' + ZW.esc(d.donorName) + '<br><small class="text-muted">' + ZW.esc(d.donorType) + '</small></td>' +
        '<td>' + ZW.esc(d.quantity + ' ' + d.unit) + '<br><small class="text-muted">' + ZW.esc(d.servings) + ' servings</small></td>' +
        '<td>' + ZW.priorityBadge(d) + '</td>' +
        '<td>' + ZW.statusBadge(d.status) + '</td>' +
        '<td>' + actionBtns(
          '<button type="button" class="btn btn-success" data-admin-advance="' + ZW.esc(d.id) + '"' +
            (d.status === last ? ' disabled' : '') + '><i class="fa-solid fa-arrow-right"></i> Advance</button>' +
          '<button type="button" class="btn btn-info" data-details="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-eye"></i></button>' +
          '<button type="button" class="btn btn-danger" data-delete-donation="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-trash"></i></button>'
        ) + '</td>' +
      '</tr>';
    }).join('');

    host.innerHTML = table(['ID', 'Food', 'Donor', 'Quantity', 'Priority', 'Status', 'Actions'], rows);
  }

  /* ------------------------------------------------------- 4. REQUEST TABLE */
  function renderRequests() {
    var host = ZW.byId('admin-requests');
    if (!host) return;
    var donations = ZW.getDonations();
    var requests = ZW.getRequests().slice().sort(function (a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
    if (!requests.length) { host.innerHTML = ZW.emptyState('No food requests', 'No receiver has requested food yet.', ''); return; }

    var rows = requests.map(function (r) {
      var d = donations.filter(function (x) { return x.id === r.donationId; })[0];
      return '<tr>' +
        '<td><strong>' + ZW.esc(r.id) + '</strong><br><small>' + ZW.esc(ZW.timeAgo(r.createdAt)) + '</small></td>' +
        '<td>' + ZW.esc(d ? d.foodName : 'Removed') + '<br><small class="text-muted">' + ZW.esc(r.donationId) + '</small></td>' +
        '<td>' + ZW.esc(r.receiverName) + '<br><small class="text-muted">' + ZW.esc(r.orgName) + '</small></td>' +
        '<td>' + ZW.esc(r.phone) + '</td>' +
        '<td>' + ZW.esc(r.servings) + '</td>' +
        '<td>' + ZW.statusBadge(r.status) + '</td>' +
        '<td>' + actionBtns(
          (r.status !== 'Accepted' && r.status !== 'Completed'
            ? '<button type="button" class="btn btn-success" data-approve-request="' + ZW.esc(r.id) + '">' +
              '<i class="fa-solid fa-check"></i> Approve</button>' +
              '<button type="button" class="btn btn-warn" data-reject-request="' + ZW.esc(r.id) + '">' +
              '<i class="fa-solid fa-ban"></i> Reject</button>'
            : '') +
          (r.status !== 'Completed'
            ? '<button type="button" class="btn btn-info" data-complete-request="' + ZW.esc(r.id) + '">' +
              '<i class="fa-solid fa-truck-fast"></i> Complete</button>' : '') +
          '<button type="button" class="btn btn-danger" data-delete-request="' + ZW.esc(r.id) + '">' +
            '<i class="fa-solid fa-trash"></i></button>'
        ) + '</td>' +
      '</tr>';
    }).join('');

    host.innerHTML = table(['Request', 'Donation', 'Receiver', 'Phone', 'Servings', 'Status', 'Actions'], rows);
  }

  function table(headings, rows) {
    return '<div class="table-wrap"><table><thead><tr>' +
      headings.map(function (h) { return '<th>' + h + '</th>'; }).join('') +
      '</tr></thead><tbody>' + rows + '</tbody></table></div>';
  }

  /* ------------------------------------------------------- 5. ACTION WIRING */
  /* One delegated listener handles every table button, so rows re-render
     freely without leaking listeners. */
  function wireActions() {
    var host = ZW.byId('admin-main');
    if (!host) return;

    host.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-approve-user], button[data-reject-user], button[data-delete-user],' +
        'button[data-admin-advance], button[data-delete-donation], button[data-approve-request],' +
        'button[data-reject-request], button[data-complete-request], button[data-delete-request]');
      if (!btn) return;

      var id;
      if ((id = btn.getAttribute('data-approve-user'))) return approveUser(id);
      if ((id = btn.getAttribute('data-reject-user'))) return revokeUser(id);
      if ((id = btn.getAttribute('data-delete-user'))) return removeItem('users', id, 'user');
      if ((id = btn.getAttribute('data-admin-advance'))) return advanceDonation(id);
      if ((id = btn.getAttribute('data-delete-donation'))) return removeItem('donations', id, 'donation');
      if ((id = btn.getAttribute('data-approve-request'))) return setRequestStatus(id, 'Accepted');
      if ((id = btn.getAttribute('data-reject-request'))) return setRequestStatus(id, 'Rejected');
      if ((id = btn.getAttribute('data-complete-request'))) return setRequestStatus(id, 'Completed');
      if ((id = btn.getAttribute('data-delete-request'))) return removeItem('requests', id, 'request');
    });

    var reset = ZW.byId('admin-reset-data');
    if (reset) {
      reset.addEventListener('click', function () {
        ZW.resetDemoData();
        ZW.logActivity('Admin restored the demo dataset', 'fa-database');
        ZW.toast('Demo data restored', 'All sample donations, users and requests were reset.', 'success');
        renderAll();
      });
    }

    var search = ZW.byId('admin-search');
    if (search) {
      search.addEventListener('input', function () {
        var term = search.value.trim().toLowerCase();
        ZW.qsa('.table-wrap tbody tr').forEach(function (row) {
          row.style.display = !term || row.textContent.toLowerCase().indexOf(term) !== -1 ? '' : 'none';
        });
      });
    }
  }

  function approveUser(id) {
    var users = ZW.getUsers();
    users.forEach(function (u) { if (u.id === id) { u.status = 'Active'; } });
    ZW.saveUsers(users);
    ZW.logActivity('Admin approved account ' + id, 'fa-user-check');
    ZW.toast('Account approved', id + ' can now sign in.', 'success');
    renderAll();
  }

  function revokeUser(id) {
    var users = ZW.getUsers();
    users.forEach(function (u) { if (u.id === id) { u.status = 'Pending Verification'; } });
    ZW.saveUsers(users);
    ZW.logActivity('Admin revoked access for ' + id, 'fa-user-lock');
    ZW.toast('Access revoked', id + ' must be approved again before signing in.', 'warn');
    renderAll();
  }

  /** Deletes a record from any collection, guarding the signed-in admin. */
  function removeItem(kind, id, label) {
    var session2 = ZW.getSession();
    if (kind === 'users' && session2 && session2.id === id) {
      ZW.toast('Cannot delete your own account', 'Sign in as another admin first.', 'error');
      return;
    }
    var list = kind === 'users' ? ZW.getUsers() : kind === 'donations' ? ZW.getDonations() : ZW.getRequests();
    var next = list.filter(function (item) { return item.id !== id; });
    if (next.length === list.length) return;
    persist(kind, next);
    ZW.logActivity('Admin deleted ' + label + ' ' + id, 'fa-trash');
    ZW.toast('Deleted', 'The ' + label + ' ' + id + ' was removed from localStorage.', 'info');
    if (!ZW.storageAvailable) ZW.toast('Storage blocked', 'This change will not survive a refresh.', 'warn');
    renderAll();
  }

  function advanceDonation(id) {
    var donations = ZW.getDonations();
    var target = donations.filter(function (d) { return d.id === id; })[0];
    if (!target) return;
    var next = ZW.STATUS_FLOW[Math.min(ZW.STATUS_FLOW.indexOf(target.status) + 1, ZW.STATUS_FLOW.length - 1)];
    if (next === target.status) { ZW.toast('Already completed', id + ' is at the end of the flow.', 'info'); return; }
    target.status = next;
    ZW.saveDonations(donations);
    ZW.logActivity('Admin moved ' + id + ' to "' + next + '"', 'fa-arrow-right-arrow-left');
    ZW.toast('Status updated', id + ' is now "' + next + '".', 'success');
    renderAll();
  }

  function setRequestStatus(id, status) {
    var requests = ZW.getRequests();
    var target = requests.filter(function (r) { return r.id === id; })[0];
    if (!target) return;
    target.status = status;
    ZW.saveRequests(requests);

    /* Keep the linked donation in step with the request. */
    if (status === 'Accepted' || status === 'Completed') {
      var donations = ZW.getDonations();
      donations.forEach(function (d) {
        if (d.id === target.donationId) d.status = status === 'Accepted' ? 'Accepted' : 'Completed';
      });
      ZW.saveDonations(donations);
    }
    ZW.logActivity('Admin set ' + id + ' to "' + status + '"', 'fa-clipboard-check');
    ZW.toast('Request updated', id + ' is now "' + status + '".', 'success');
    renderAll();
  }

  /* -------------------------------------------------------------- 6. RENDER */
  function renderAll() {
    renderStats();
    renderUsers();
    renderDonations();
    renderRequests();
  }

  /* ---------------------------------------------------------------- 7. INIT */
  function init() {
    if (!ZW.byId('admin-kpis')) return;
    session = ZW.auth.requireSession('admin');
    if (!session) return;

    var who = ZW.byId('admin-who');
    if (who) who.textContent = session.name;
    renderAll();
    wireActions();
    ZW.toast('Admin console', 'Signed in as ' + session.name + '. Actions are saved in localStorage.', 'info', 4200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
