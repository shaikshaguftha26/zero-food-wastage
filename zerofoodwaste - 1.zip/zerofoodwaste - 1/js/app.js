/* ==========================================================================
   ZeroWaste - app.js
   Core layer shared by every page:
     - localStorage wrapper (with in-memory fallback)
     - sample data seeding (restaurants, households, NGOs, canteens, caterers)
     - date / distance / formatting helpers
     - "AI-style" simulations: servings estimation, freshness index,
       rescue priority score, donor-receiver match score
     - UI shell: header, mobile drawer, footer, toasts, theme, scroll reveal
   ========================================================================== */
(function () {
  'use strict';

  var ZW = (window.ZW = window.ZW || {});

  /* ---------------------------------------------------------------- 1. KEYS */
  var KEYS = {
    donations: 'zw_donations',
    requests: 'zw_requests',
    users: 'zw_users',
    session: 'zw_session',
    theme: 'zw_theme',
    seed: 'zw_seed_version',
    activity: 'zw_activity',
    userLocation: 'zw_user_location',
    newsletter: 'zw_newsletter',
    remembered: 'zw_remembered'
  };
  ZW.KEYS = KEYS;

  /* Demo data version - bump this string to force a fresh demo dataset. */
  var SEED_VERSION = 'zw-1.0.0';

  /* Donation lifecycle. Every status change walks along this path. */
  var STATUS_FLOW = ['Pending', 'Accepted', 'Pickup Scheduled', 'Picked Up', 'Delivered', 'Completed'];
  var STATUS_CLASS = {
    'Pending': 'pending',
    'Accepted': 'accepted',
    'Pickup Scheduled': 'scheduled',
    'Picked Up': 'picked',
    'Delivered': 'delivered',
    'Completed': 'completed',
    'Rejected': 'rejected',
    'Expired': 'expired'
  };
  var CATEGORY_LABEL = { veg: 'Vegetarian', nonveg: 'Non-Vegetarian', vegan: 'Vegan' };
  var CATEGORY_CLASS = { veg: 'veg', nonveg: 'nonveg', vegan: 'vegan' };
  var FOOD_TYPES = ['Cooked Meal', 'Bakery', 'Raw Produce', 'Fruits', 'Dairy', 'Packaged', 'Beverages'];
  var DONOR_TYPES = ['Household', 'Restaurant', 'Hotel', 'Caterer', 'Canteen', 'Event'];
  var UNITS = ['kg', 'litres', 'plates', 'boxes', 'packets', 'grams'];

  ZW.STATUS_FLOW = STATUS_FLOW;
  ZW.FOOD_TYPES = FOOD_TYPES;
  ZW.DONOR_TYPES = DONOR_TYPES;
  ZW.UNITS = UNITS;
  ZW.CATEGORY_LABEL = CATEGORY_LABEL;

  /* Hyderabad city centre - the default "you are here" pin for the demo. */
  var DEFAULT_LOCATION = { label: 'Hyderabad, Telangana', lat: 17.3850, lng: 78.4867 };
  ZW.DEFAULT_LOCATION = DEFAULT_LOCATION;

  /* ------------------------------------------------------- 2. STORAGE LAYER */
  var memStore = {}; // fallback when localStorage is blocked (private mode, file://, etc.)

  function lsAvailable() {
    try {
      var k = '__zw_probe__';
      window.localStorage.setItem(k, '1');
      window.localStorage.removeItem(k);
      return true;
    } catch (e) {
      return false;
    }
  }
  ZW.storageAvailable = lsAvailable();

  function storeGet(key, fallback) {
    try {
      var raw = window.localStorage.getItem(key);
      if (raw === null || raw === undefined) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      return Object.prototype.hasOwnProperty.call(memStore, key) ? memStore[key] : fallback;
    }
  }

  function storeSet(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      memStore[key] = value; // keep the demo working for this session
      return false;
    }
  }
  ZW.storeGet = storeGet;
  ZW.storeSet = storeSet;

  /* Public helpers so every page mutates the same collections. */
  ZW.getDonations = function () { return storeGet(KEYS.donations, []); };
  ZW.saveDonations = function (list) { return storeSet(KEYS.donations, list); };
  ZW.getRequests = function () { return storeGet(KEYS.requests, []); };
  ZW.saveRequests = function (list) { return storeSet(KEYS.requests, list); };
  ZW.getUsers = function () { return storeGet(KEYS.users, []); };
  ZW.saveUsers = function (list) { return storeSet(KEYS.users, list); };
  ZW.getActivity = function () { return storeGet(KEYS.activity, []); };
  ZW.getSession = function () { return storeGet(KEYS.session, null); };
  ZW.saveSession = function (s) { return storeSet(KEYS.session, s); };
  ZW.logout = function () {
    try { window.localStorage.removeItem(KEYS.session); } catch (e) { memStore[KEYS.session] = null; }
  };

  /* Append an entry to the dashboard activity feed (newest first, capped). */
  ZW.logActivity = function (text, icon, tone) {
    var list = ZW.getActivity();
    list.unshift({ text: text, icon: icon || 'fa-circle-check', tone: tone || 'green', at: new Date().toISOString() });
    storeSet(KEYS.activity, list.slice(0, 30));
  };

  /* ------------------------------------------------------- 3. SAMPLE DATA */
  /* Dates are generated relative to "now" so the demo always looks live:
     freshly prepared food, food expiring soon, and completed rescues. */
  function hoursFromNow(h) { return new Date(Date.now() + h * 3600 * 1000); }
  /* Local (not UTC) YYYY-MM-DD so freshness math matches the viewer's timezone. */
  function dayStr(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function pad2(n) { return String(n).padStart(2, '0'); }
  function localStamp(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
      'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  ZW.localStamp = localStamp;

  function seedUsers() {
    return [
      { id: 'ZWU-001', name: 'Admin Control', email: 'admin@zerowaste.org', password: 'admin123',
        role: 'admin', org: 'ZeroWaste Platform', phone: '+91 90000 00001', city: 'Hyderabad',
        status: 'Active', joinedAt: hoursFromNow(-2400).toISOString() },
      { id: 'ZWU-002', name: 'Spice Garden Restaurant', email: 'donor@spicegarden.com', password: 'donor123',
        role: 'donor', org: 'Spice Garden Restaurant', phone: '+91 98490 11122', city: 'Hyderabad',
        donorType: 'Restaurant', status: 'Active', joinedAt: hoursFromNow(-1800).toISOString() },
      { id: 'ZWU-003', name: 'Ananya Sharma', email: 'ananya@home.com', password: 'home123',
        role: 'donor', org: 'Household', phone: '+91 99630 44556', city: 'Bengaluru',
        donorType: 'Household', status: 'Active', joinedAt: hoursFromNow(-1200).toISOString() },
      { id: 'ZWU-004', name: 'Green Leaf Canteen', email: 'canteen@greenleaf.com', password: 'canteen123',
        role: 'donor', org: 'Green Leaf Canteen', phone: '+91 97050 77889', city: 'Hyderabad',
        donorType: 'Canteen', status: 'Active', joinedAt: hoursFromNow(-900).toISOString() },
      { id: 'ZWU-005', name: 'Helping Hands NGO', email: 'ngo@helpinghands.org', password: 'ngo123',
        role: 'receiver', org: 'Helping Hands Foundation', phone: '+91 90100 22233', city: 'Hyderabad',
        status: 'Active', joinedAt: hoursFromNow(-1500).toISOString() },
      { id: 'ZWU-006', name: 'Asha Shelter Home', email: 'care@ashashelter.org', password: 'shelter123',
        role: 'receiver', org: 'Asha Shelter Home', phone: '+91 90300 55667', city: 'Bengaluru',
        status: 'Active', joinedAt: hoursFromNow(-700).toISOString() },
      { id: 'ZWU-007', name: 'Rahul Verma', email: 'rahul@volunteer.in', password: 'volunteer123',
        role: 'receiver', org: 'Independent Volunteer', phone: '+91 98990 33445', city: 'Hyderabad',
        status: 'Pending Verification', joinedAt: hoursFromNow(-30).toISOString() },
      { id: 'ZWU-008', name: 'Tandoor Nights Hotel', email: 'kitchen@tandoornights.com', password: 'hotel123',
        role: 'donor', org: 'Tandoor Nights Hotel', phone: '+91 99880 66778', city: 'Mumbai',
        donorType: 'Hotel', status: 'Pending Verification', joinedAt: hoursFromNow(-14).toISOString() }
    ];
  }

  function seedRequests() {
    return [
      { id: 'ZWR-2001', donationId: 'ZWD-1002', receiverName: 'Sr. Meera Joseph',
        orgName: 'Helping Hands Foundation', phone: '+91 90100 22233', servings: 40,
        pickupPref: 'Own vehicle', note: 'Evening distribution drive for 40 families.',
        status: 'Accepted', createdAt: hoursFromNow(-8).toISOString() },
      { id: 'ZWR-2002', donationId: 'ZWD-1005', receiverName: 'Karthik Rao',
        orgName: 'Asha Shelter Home', phone: '+91 90300 55667', servings: 25,
        pickupPref: 'Need volunteer pickup', note: 'Shelter has 25 residents.',
        status: 'Completed', createdAt: hoursFromNow(-52).toISOString() },
      { id: 'ZWR-2003', donationId: 'ZWD-1007', receiverName: 'Nisha Patel',
        orgName: 'Sunrise Community Kitchen', phone: '+91 90777 12345', servings: 60,
        pickupPref: 'Own vehicle', note: 'Breakfast for community kitchen.',
        status: 'Pending', createdAt: hoursFromNow(-3).toISOString() },
      { id: 'ZWR-2004', donationId: 'ZWD-1010', receiverName: 'Rahul Verma',
        orgName: 'Independent Volunteer', phone: '+91 98990 33445', servings: 15,
        pickupPref: 'Need volunteer pickup', note: 'Distributing near metro station.',
        status: 'Pending', createdAt: hoursFromNow(-1).toISOString() }
    ];
  }

  /* 14 realistic donations across 6 cities. status/city/lat/lng drive the
     filters, sorting and distance calculations on the Receive + Map pages. */
  function seedDonations() {
    var list = [
      { id: 'ZWD-1001', foodName: 'Veg Biryani & Raita', foodType: 'Cooked Meal', category: 'veg',
        quantity: 14, unit: 'kg', servings: 46, prepDate: dayStr(hoursFromNow(-3)),
        expiryDate: dayStr(hoursFromNow(9)), pickupDeadline: localStamp(hoursFromNow(5)),
        address: 'Plot 22, Jubilee Hills Road No. 36', city: 'Hyderabad',
        lat: 17.4325, lng: 78.4073, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=70',
        description: 'Freshly cooked vegetable biryani with raita from today\'s lunch buffet. Kept in sealed food-grade containers.',
        donorName: 'Spice Garden Restaurant', donorType: 'Restaurant', donorEmail: 'donor@spicegarden.com',
        donorPhone: '+91 98490 11122', status: 'Pending', createdAt: hoursFromNow(-3).toISOString() },

      { id: 'ZWD-1002', foodName: 'Assorted Sandwich Trays', foodType: 'Packaged', category: 'veg',
        quantity: 60, unit: 'plates', servings: 60, prepDate: dayStr(hoursFromNow(-5)),
        expiryDate: dayStr(hoursFromNow(7)), pickupDeadline: localStamp(hoursFromNow(4)),
        address: 'HITEC City Convention Hall, Madhapur', city: 'Hyderabad',
        lat: 17.4483, lng: 78.3915, image: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=800&q=70',
        description: 'Corporate event surplus: 60 packed veg sandwich plates, never served, still sealed.',
        donorName: 'TechNova Events', donorType: 'Event', donorEmail: 'events@technova.in',
        donorPhone: '+91 90000 45678', status: 'Accepted', createdAt: hoursFromNow(-6).toISOString() },

      { id: 'ZWD-1003', foodName: 'Chapati & Dal Curry', foodType: 'Cooked Meal', category: 'veg',
        quantity: 9, unit: 'kg', servings: 30, prepDate: dayStr(hoursFromNow(-2)),
        expiryDate: dayStr(hoursFromNow(6)), pickupDeadline: localStamp(hoursFromNow(3)),
        address: '12-4-88, Ameerpet Main Road', city: 'Hyderabad',
        lat: 17.4374, lng: 78.4487, image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=70',
        description: 'Home-cooked chapati and dal, prepared for a family function. Extra 30 servings available.',
        donorName: 'Ananya Sharma', donorType: 'Household', donorEmail: 'ananya@home.com',
        donorPhone: '+91 99630 44556', status: 'Pending', createdAt: hoursFromNow(-2).toISOString() },

      { id: 'ZWD-1004', foodName: 'Fresh Fruit Crates', foodType: 'Fruits', category: 'vegan',
        quantity: 22, unit: 'kg', servings: 88, prepDate: dayStr(hoursFromNow(-20)),
        expiryDate: dayStr(hoursFromNow(52)), pickupDeadline: localStamp(hoursFromNow(40)),
        address: 'Gandhi Fruit Market, Kothapet', city: 'Hyderabad',
        lat: 17.3709, lng: 78.5409, image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=800&q=70',
        description: 'Slightly ripe bananas, apples and oranges - perfect for immediate distribution.',
        donorName: 'Kothapet Fruit Traders', donorType: 'Caterer', donorEmail: 'sales@kothapetfruits.in',
        donorPhone: '+91 99887 12000', status: 'Pending', createdAt: hoursFromNow(-20).toISOString() },

      { id: 'ZWD-1005', foodName: 'Mixed Veg Thali', foodType: 'Cooked Meal', category: 'veg',
        quantity: 25, unit: 'plates', servings: 25, prepDate: dayStr(hoursFromNow(-30)),
        expiryDate: dayStr(hoursFromNow(-6)), pickupDeadline: localStamp(hoursFromNow(-8)),
        address: 'Green Leaf Canteen, Sector 4, Kukatpally', city: 'Hyderabad',
        lat: 17.4849, lng: 78.4138, image: 'https://images.unsplash.com/photo-1626500155537-8f5dfac1e2c8?auto=format&fit=crop&w=800&q=70',
        description: 'Canteen surplus thali collected and delivered to Asha Shelter Home.',
        donorName: 'Green Leaf Canteen', donorType: 'Canteen', donorEmail: 'canteen@greenleaf.com',
        donorPhone: '+91 97050 77889', status: 'Completed', createdAt: hoursFromNow(-30).toISOString() },

      { id: 'ZWD-1006', foodName: 'Chicken Curry & Rice', foodType: 'Cooked Meal', category: 'nonveg',
        quantity: 11, unit: 'kg', servings: 33, prepDate: dayStr(hoursFromNow(-4)),
        expiryDate: dayStr(hoursFromNow(5)), pickupDeadline: localStamp(hoursFromNow(2.5)),
        address: 'Tandoor Nights, Linking Road, Bandra West', city: 'Mumbai',
        lat: 19.0596, lng: 72.8295, image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=800&q=70',
        description: 'Restaurant surplus chicken curry with steamed rice. Refrigerated since preparation.',
        donorName: 'Tandoor Nights Hotel', donorType: 'Hotel', donorEmail: 'kitchen@tandoornights.com',
        donorPhone: '+91 99880 66778', status: 'Pickup Scheduled', createdAt: hoursFromNow(-4).toISOString() },

      { id: 'ZWD-1007', foodName: 'Idli, Vada & Sambar', foodType: 'Cooked Meal', category: 'veg',
        quantity: 18, unit: 'kg', servings: 72, prepDate: dayStr(hoursFromNow(-1)),
        expiryDate: dayStr(hoursFromNow(8)), pickupDeadline: localStamp(hoursFromNow(5)),
        address: 'Sunrise Tiffin Centre, Jayanagar 4th Block', city: 'Bengaluru',
        lat: 12.9250, lng: 77.5938, image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=70',
        description: 'Morning breakfast surplus - idli, vada and sambar. Ideal for a community breakfast.',
        donorName: 'Sunrise Tiffin Centre', donorType: 'Restaurant', donorEmail: 'hello@sunrisetiffin.in',
        donorPhone: '+91 90080 55123', status: 'Pending', createdAt: hoursFromNow(-1).toISOString() }
    ];
    return list;
  }

  function seedDonationsPartTwo() {
    return [
      { id: 'ZWD-1008', foodName: 'Bakery Bread & Buns', foodType: 'Bakery', category: 'veg',
        quantity: 15, unit: 'kg', servings: 60, prepDate: dayStr(hoursFromNow(-14)),
        expiryDate: dayStr(hoursFromNow(30)), pickupDeadline: localStamp(hoursFromNow(24)),
        address: 'Anand Bakery, MG Road', city: 'Pune',
        lat: 18.5158, lng: 73.8790, image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=70',
        description: 'Day-old but perfectly safe bread loaves, buns and pav. Great for breakfast distribution.',
        donorName: 'Anand Bakery', donorType: 'Restaurant', donorEmail: 'orders@anandbakery.in',
        donorPhone: '+91 90210 33445', status: 'Pending', createdAt: hoursFromNow(-14).toISOString() },

      { id: 'ZWD-1009', foodName: 'Paneer Butter Masala', foodType: 'Cooked Meal', category: 'veg',
        quantity: 8, unit: 'kg', servings: 24, prepDate: dayStr(hoursFromNow(-2.5)),
        expiryDate: dayStr(hoursFromNow(6)), pickupDeadline: localStamp(hoursFromNow(3)),
        address: 'Hotel Emerald, Anna Salai', city: 'Chennai',
        lat: 13.0604, lng: 80.2496, image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=70',
        description: 'Wedding banquet surplus paneer butter masala, prepared this afternoon.',
        donorName: 'Hotel Emerald Banquets', donorType: 'Hotel', donorEmail: 'banquet@emeraldchennai.com',
        donorPhone: '+91 94440 55667', status: 'Accepted', createdAt: hoursFromNow(-2.5).toISOString() },

      { id: 'ZWD-1010', foodName: 'Vegetable Pulao & Curd', foodType: 'Cooked Meal', category: 'veg',
        quantity: 12, unit: 'kg', servings: 40, prepDate: dayStr(hoursFromNow(-4)),
        expiryDate: dayStr(hoursFromNow(4)), pickupDeadline: localStamp(hoursFromNow(2)),
        address: 'Community Hall, Sector 21, Dwarka', city: 'Delhi',
        lat: 28.5823, lng: 77.0500, image: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=800&q=70',
        description: 'Community event surplus pulao with curd. Needs pickup within a couple of hours.',
        donorName: 'Dwarka Community Events', donorType: 'Event', donorEmail: 'coordinator@dwarkaevents.in',
        donorPhone: '+91 98110 22334', status: 'Pending', createdAt: hoursFromNow(-4).toISOString() },

      { id: 'ZWD-1011', foodName: 'Milk & Curd Packets', foodType: 'Dairy', category: 'veg',
        quantity: 30, unit: 'litres', servings: 120, prepDate: dayStr(hoursFromNow(-8)),
        expiryDate: dayStr(hoursFromNow(20)), pickupDeadline: localStamp(hoursFromNow(14)),
        address: 'Sri Balaji Dairy, Kothrud', city: 'Pune',
        lat: 18.5074, lng: 73.8077, image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=800&q=70',
        description: 'Unopened milk and curd packets approaching their best-before date. Chilled storage.',
        donorName: 'Sri Balaji Dairy', donorType: 'Household', donorEmail: 'balajidairy@mail.in',
        donorPhone: '+91 97650 88990', status: 'Pending', createdAt: hoursFromNow(-8).toISOString() },

      { id: 'ZWD-1012', foodName: 'South Indian Meals', foodType: 'Cooked Meal', category: 'veg',
        quantity: 20, unit: 'plates', servings: 20, prepDate: dayStr(hoursFromNow(-1.5)),
        expiryDate: dayStr(hoursFromNow(7)), pickupDeadline: localStamp(hoursFromNow(4)),
        address: 'Catering Unit, T. Nagar', city: 'Chennai',
        lat: 13.0400, lng: 80.2337, image: 'https://images.unsplash.com/photo-1630383249896-424e482df921?auto=format&fit=crop&w=800&q=70',
        description: 'Caterer surplus banana-leaf meals from a reception. Hygienically packed.',
        donorName: 'Sakthi Caterers', donorType: 'Caterer', donorEmail: 'bookings@sakthicaterers.in',
        donorPhone: '+91 98840 11002', status: 'Delivered', createdAt: hoursFromNow(-9).toISOString() },

      { id: 'ZWD-1013', foodName: 'Fruit Salad Bowls', foodType: 'Fruits', category: 'vegan',
        quantity: 45, unit: 'boxes', servings: 45, prepDate: dayStr(hoursFromNow(-3)),
        expiryDate: dayStr(hoursFromNow(9)), pickupDeadline: localStamp(hoursFromNow(6)),
        address: 'Fresh Express Cafe, Indiranagar', city: 'Bengaluru',
        lat: 12.9719, lng: 77.6412, image: 'https://images.unsplash.com/photo-1519996529931-28324d5a630e?auto=format&fit=crop&w=800&q=70',
        description: 'Sealed fruit salad boxes from a cancelled office order. Vegan and ready to serve.',
        donorName: 'Fresh Express Cafe', donorType: 'Restaurant', donorEmail: 'care@freshexpress.in',
        donorPhone: '+91 91080 66007', status: 'Pending', createdAt: hoursFromNow(-3).toISOString() },

      { id: 'ZWD-1014', foodName: 'Cooked Rice & Sambar', foodType: 'Cooked Meal', category: 'veg',
        quantity: 16, unit: 'kg', servings: 54, prepDate: dayStr(hoursFromNow(-6)),
        expiryDate: dayStr(hoursFromNow(-1)), pickupDeadline: localStamp(hoursFromNow(-2)),
        address: 'Govt. School Canteen, Kukatpally', city: 'Hyderabad',
        lat: 17.4948, lng: 78.3996, image: 'https://images.unsplash.com/photo-1596560548464-f010549b84d7?auto=format&fit=crop&w=800&q=70',
        description: 'School canteen surplus rice and sambar, rescued and delivered on time.',
        donorName: 'Govt. School Canteen', donorType: 'Canteen', donorEmail: 'canteen@govtschool.in',
        donorPhone: '+91 90000 12345', status: 'Completed', createdAt: hoursFromNow(-11).toISOString() }
    ];
  }

  /* -------------------------------------------------------- 4. SEED WRITER */
  /* Writes the demo dataset into localStorage once per SEED_VERSION. */
  ZW.seed = function (force) {
    var current = storeGet(KEYS.seed, null);
    if (!force && current === SEED_VERSION) return false;
    ZW.saveUsers(seedUsers());
    ZW.saveRequests(seedRequests());
    ZW.saveDonations(seedDonations().concat(seedDonationsPartTwo()));
    storeSet(KEYS.seed, SEED_VERSION);
    storeSet(KEYS.activity, [
      { text: 'Demo dataset loaded - 14 donations, 8 accounts, 4 requests', icon: 'fa-database', tone: 'green', at: new Date().toISOString() }
    ]);
    return true;
  };

  ZW.resetDemoData = function () { return ZW.seed(true); };
  ZW.SEED_VERSION = SEED_VERSION;

  /* --------------------------------------------------------- 5. HELPERS */
  function pad(n) { return String(n).padStart(2, '0'); }
  ZW.pad = pad;

  /** Escape user-supplied text before injecting it into innerHTML. */
  ZW.esc = function (str) {
    return String(str === undefined || str === null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  ZW.byId = function (id) { return document.getElementById(id); };
  ZW.qs = function (sel, root) { return (root || document).querySelector(sel); };
  ZW.qsa = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  /** Hours between now and a date value. Negative = already in the past. */
  ZW.hoursUntil = function (value) {
    if (!value) return NaN;
    var t = new Date(value).getTime();
    if (isNaN(t)) return NaN;
    return (t - Date.now()) / 3600000;
  };

  ZW.formatDate = function (value) {
    if (!value) return '-';
    var d = new Date(value);
    if (isNaN(d.getTime())) return String(value);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  ZW.formatDateTime = function (value) {
    if (!value) return '-';
    var d = new Date(value);
    if (isNaN(d.getTime())) return String(value);
    return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  /** "3h left" / "2d left" / "overdue by 4h" - used for deadline chips. */
  ZW.deadlineText = function (value) {
    var h = ZW.hoursUntil(value);
    if (isNaN(h)) return 'No deadline';
    var overdue = h < 0;
    var abs = Math.abs(h);
    var text;
    if (abs < 1) text = Math.round(abs * 60) + ' min';
    else if (abs < 24) text = Math.round(abs) + ' hr';
    else text = Math.round(abs / 24) + ' day' + (Math.round(abs / 24) === 1 ? '' : 's');
    return overdue ? 'Overdue by ' + text : text + ' left';
  };

  ZW.timeAgo = function (value) {
    var h = ZW.hoursUntil(value) * -1;
    if (isNaN(h)) return 'just now';
    if (h < 1) return Math.max(1, Math.round(h * 60)) + ' min ago';
    if (h < 24) return Math.round(h) + ' hr ago';
    return Math.round(h / 24) + ' day(s) ago';
  };

  ZW.initials = function (name) {
    var parts = String(name || '?').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  /** Haversine distance in km - powers "distance" filters and the map. */
  ZW.distanceKm = function (a, b) {
    if (!a || !b) return NaN;
    var R = 6371, toRad = function (x) { return (x * Math.PI) / 180; };
    var dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
    var s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return Math.round(2 * R * Math.asin(Math.sqrt(s)) * 10) / 10;
  };

  /** The receiver's saved "current location" (falls back to city centre). */
  ZW.getUserLocation = function () { return storeGet(KEYS.userLocation, DEFAULT_LOCATION); };
  ZW.saveUserLocation = function (loc) { return storeSet(KEYS.userLocation, loc); };

  ZW.statusBadge = function (status) {
    var cls = STATUS_CLASS[status] || 'neutral';
    return '<span class="badge badge-' + cls + '">' + ZW.esc(status) + '</span>';
  };

  ZW.categoryBadge = function (category) {
    var cls = CATEGORY_CLASS[category] || 'neutral';
    return '<span class="badge badge-' + cls + '"><i class="fa-solid fa-leaf"></i> ' +
      ZW.esc(CATEGORY_LABEL[category] || category) + '</span>';
  };

  ZW.donorIcon = function (type) {
    var map = {
      Restaurant: 'fa-utensils', Household: 'fa-house-chimney', Hotel: 'fa-hotel',
      Caterer: 'fa-truck-fast', Canteen: 'fa-store', Event: 'fa-champagne-glasses'
    };
    return map[type] || 'fa-building';
  };

  /* --------------------------------------- 6. AI-STYLE SIMULATIONS (demo) */
  /* These are transparent Heuristic/rule-based helpers, NOT a trained model.
     They only exist to make the demo feel smart; every number is derived
     from data the user typed in (quantity, dates, distance). */

  /* Servings per unit for each food type - used by the estimator. */
  var SERVINGS_PER_UNIT = {
    'Cooked Meal': 3.2, 'Bakery': 4, 'Raw Produce': 4.5, 'Fruits': 4,
    'Dairy': 4, 'Packaged': 2.5, 'Beverages': 4
  };
  /* How quickly each food type loses freshness (higher = more perishable). */
  var PERISHABILITY = {
    'Cooked Meal': 20, 'Dairy': 16, 'Fruits': 13, 'Bakery': 12,
    'Raw Produce': 11, 'Beverages': 7, 'Packaged': 5
  };

  /**
   * 1) Food quantity -> estimated servings.
   * Rule: servings/unit depends on food type, unit and diet category.
   */
  ZW.estimateServings = function (quantity, unit, foodType, category) {
    var qty = parseFloat(quantity);
    if (!qty || isNaN(qty) || qty <= 0) return 0;
    if (unit === 'plates') return Math.round(qty);
    if (unit === 'boxes') return Math.round(qty * 1);
    if (unit === 'packets') return Math.round(qty * 1.5);
    var per = SERVINGS_PER_UNIT[foodType] || 3.2;
    if (unit === 'grams') return Math.round((qty / 1000) * per);
    if (unit === 'litres') per = per * 0.85; // liquids serve slightly less per litre
    var dietFactor = category === 'vegan' ? 1.05 : (category === 'nonveg' ? 0.95 : 1);
    var servings = qty * per * dietFactor;
    return Math.max(1, Math.round(servings));
  };

  /**
   * 2) Freshness index (0-100) + a human label.
   * Rule: fraction of the safe window (prep -> expiry) still remaining.
   */
  ZW.freshness = function (donation) {
    var expiry = new Date(donation.expiryDate).getTime();
    var prep = new Date(donation.prepDate).getTime();
    if (isNaN(expiry)) return { percent: 0, label: 'Unknown', tone: 'danger' };
    if (isNaN(prep) || prep >= expiry) prep = expiry - 24 * 3600 * 1000;
    var total = expiry - prep;
    var left = expiry - Date.now();
    var percent = Math.max(0, Math.min(100, Math.round((left / total) * 100)));
    var label, tone;
    if (left <= 0) { percent = 0; label = 'Expired'; tone = 'danger'; }
    else if (percent < 20) { label = 'Expiring soon'; tone = 'danger'; }
    else if (percent < 45) { label = 'Use soon'; tone = 'warn'; }
    else if (percent < 70) { label = 'Good'; tone = 'ok'; }
    else { label = 'Very fresh'; tone = 'ok'; }
    return { percent: percent, label: label, tone: tone };
  };

  /**
   * 3) Rescue Priority Score (0-100) -> High / Medium / Low.
   * Weighted rule: urgency (40) + servings (25) + perishability (20) + distance (15).
   */
  ZW.priority = function (donation, location) {
    var hours = ZW.hoursUntil(donation.pickupDeadline || donation.expiryDate);
    var urgency;
    if (isNaN(hours)) urgency = 5;
    else if (hours <= 0) urgency = 40;
    else if (hours <= 3) urgency = 38;
    else if (hours <= 6) urgency = 32;
    else if (hours <= 12) urgency = 25;
    else if (hours <= 24) urgency = 17;
    else if (hours <= 48) urgency = 9;
    else urgency = 4;

    var servings = Number(donation.servings) || 0;
    var volume;
    if (servings >= 100) volume = 25;
    else if (servings >= 50) volume = 21;
    else if (servings >= 25) volume = 16;
    else if (servings >= 10) volume = 11;
    else volume = 5;

    var perish = PERISHABILITY[donation.foodType] || 10;

    var km = ZW.distanceKm(location || ZW.getUserLocation(), donation);
    var proximity;
    if (isNaN(km)) proximity = 5;
    else if (km <= 3) proximity = 15;
    else if (km <= 8) proximity = 11;
    else if (km <= 15) proximity = 7;
    else if (km <= 30) proximity = 4;
    else proximity = 2;

    var score = Math.min(100, urgency + volume + perish + proximity);
    var level = score >= 72 ? 'High' : (score >= 50 ? 'Medium' : 'Low');
    return { score: score, level: level, parts: { urgency: urgency, volume: volume, perishability: perish, proximity: proximity, km: km } };
  };

  ZW.priorityBadge = function (donation, location) {
    var p = ZW.priority(donation, location);
    var cls = p.level === 'High' ? 'high' : (p.level === 'Medium' ? 'medium' : 'low');
    return '<span class="badge badge-priority-' + cls + '" title="Rescue Priority Score: ' + p.score + '/100">' +
      '<i class="fa-solid fa-bolt"></i> ' + p.level + ' Priority</span>';
  };

  /**
   * 4) Smart donor <-> receiver matching.
   * Scores how well a receiver's request fits an available donation (0-100):
   * servings coverage, pickup ability, distance, freshness and priority.
   */
  ZW.matchScore = function (donation, request, location) {
    if (!donation || !request) return 0;
    var score = 0;
    var wanted = Number(request.servings) || 0;
    var available = Number(donation.servings) || 0;
    if (available >= wanted && wanted > 0) score += 30;
    else if (available > 0) score += Math.round((available / Math.max(wanted, 1)) * 24);
    score += request.pickupPref === 'Own vehicle' ? 12 : 6;
    var km = ZW.distanceKm(location || ZW.getUserLocation(), donation);
    if (!isNaN(km)) { if (km <= 5) score += 18; else if (km <= 12) score += 12; else if (km <= 25) score += 6; }
    score += Math.round((ZW.freshness(donation).percent / 100) * 18);
    score += donation.status === 'Pending' ? 10 : 4;
    score += Math.round((ZW.priority(donation, location).score / 100) * 12);
    return Math.max(5, Math.min(100, score));
  };

  /* Highest-scoring pending donation for the signed-in receiver, if any. */
  ZW.bestMatchFor = function (donations, request) {
    var best = null, bestScore = -1;
    (donations || []).forEach(function (d) {
      if (d.status !== 'Pending') return;
      var s = ZW.matchScore(d, request);
      if (s > bestScore) { bestScore = s; best = d; }
    });
    return best ? { donation: best, score: bestScore } : null;
  };

  /* --------------------------------------------- 7. TOASTS & NOTIFICATIONS */
  function toastHost() {
    var host = ZW.byId('toast-stack');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toast-stack';
      host.className = 'toast-stack';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    return host;
  }

  var TOAST_ICON = { success: 'fa-circle-check', error: 'fa-circle-exclamation', warn: 'fa-triangle-exclamation', info: 'fa-circle-info' };

  /** Non-blocking notification. type: success | error | warn | info */
  ZW.toast = function (title, message, type, ms) {
    type = type || 'success';
    var host = toastHost();
    var el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML =
      '<i class="fa-solid ' + (TOAST_ICON[type] || TOAST_ICON.success) + ' lead"></i>' +
      '<div><strong>' + ZW.esc(title) + '</strong>' + (message ? '<p>' + ZW.esc(message) + '</p>' : '') + '</div>' +
      '<button type="button" class="toast-close" aria-label="Dismiss notification"><i class="fa-solid fa-xmark"></i></button>';
    host.appendChild(el);
    var close = function () {
      el.classList.add('is-out');
      window.setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 320);
    };
    el.querySelector('.toast-close').addEventListener('click', close);
    window.setTimeout(close, ms || 4200);
    return el;
  };

  /* ------------------------------------------------------ 8. MODAL MANAGER */
  var activeModal = null;
  ZW.openModal = function (id) {
    var el = ZW.byId(id);
    if (!el) return;
    el.classList.add('is-open');
    el.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    activeModal = el;
    var focusable = el.querySelector('input, select, textarea, button');
    if (focusable) window.setTimeout(function () { focusable.focus(); }, 120);
  };
  ZW.closeModal = function (id) {
    var el = id ? ZW.byId(id) : activeModal;
    if (!el) return;
    el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    if (activeModal === el) activeModal = null;
  };

  /* Close on backdrop click / Escape / any [data-close-modal] button. */
  function wireModalDismiss() {
    document.addEventListener('click', function (e) {
      var closer = e.target.closest('[data-close-modal]');
      if (closer) { ZW.closeModal(closer.getAttribute('data-close-modal') || undefined); return; }
      if (e.target.classList && e.target.classList.contains('modal-backdrop')) ZW.closeModal(e.target.id);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && activeModal) ZW.closeModal(activeModal.id);
    });
  }

  /* ----------------------------------------------------- 9. THEME HANDLING */
  ZW.applyTheme = function (theme) {
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    storeSet(KEYS.theme, theme);
  };
  ZW.toggleTheme = function () {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    ZW.applyTheme(next);
    return next;
  };
  /* Applied as early as possible to avoid a flash of the wrong theme. */
  (function initTheme() {
    var saved = storeGet(KEYS.theme, null);
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute('data-theme', saved ? saved : (prefersDark ? 'dark' : 'light'));
  })();

  /* --------------------------------------------------- 10. UI SHELL (NAV) */
  var NAV_LINKS = [
    { href: 'index.html', label: 'Home', icon: 'fa-house' },
    { href: 'donate.html', label: 'Donate Food', icon: 'fa-hand-holding-heart' },
    { href: 'receive.html', label: 'Receive Food', icon: 'fa-bowl-food' },
    { href: 'map.html', label: 'Food Map', icon: 'fa-map-location-dot' },
    { href: 'index.html#how', label: 'How It Works', icon: 'fa-diagram-project' },
    { href: 'about.html', label: 'About', icon: 'fa-circle-info' }
  ];

  function sessionArea() {
    var s = ZW.getSession();
    if (!s) {
      return '<a href="login.html" class="btn btn-primary btn-sm"><i class="fa-solid fa-right-to-bracket"></i> Login</a>';
    }
    return '<a href="dashboard.html" class="user-chip" title="Open your dashboard">' +
      '<span class="avatar">' + ZW.esc(ZW.initials(s.name)) + '</span>' +
      '<span>' + ZW.esc(String(s.name).split(' ')[0]) + ' <small class="text-muted">(' + ZW.esc(s.role) + ')</small></span>' +
      '</a>' +
      '<button type="button" class="btn btn-outline btn-sm" id="logout-btn"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</button>';
  }

  function drawerExtra() {
    var s = ZW.getSession();
    if (!s) return '<li><a href="register.html" data-page="register"><i class="fa-solid fa-user-plus"></i> Register</a></li>';
    var admin = s.role === 'admin'
      ? '<li><a href="admin.html" data-page="admin"><i class="fa-solid fa-shield-halved"></i> Admin Panel</a></li>' : '';
    return '<li><a href="dashboard.html" data-page="dashboard"><i class="fa-solid fa-gauge-high"></i> My Dashboard</a></li>' + admin;
  }

  function renderHeader() {
    var root = ZW.byId('header-root');
    if (!root) return;
    var page = document.body.getAttribute('data-page') || '';
    var links = NAV_LINKS.map(function (l) {
      var cls = l.href.indexOf('#') === -1 && l.href.replace('.html', '') === page ? ' class="active"' : '';
      return '<li><a href="' + l.href + '"' + cls + '>' + l.label + '</a></li>';
    }).join('');
    var drawerLinks = NAV_LINKS.map(function (l) {
      var cls = l.href.indexOf('#') === -1 && l.href.replace('.html', '') === page ? ' class="active"' : '';
      return '<li><a href="' + l.href + '"' + cls + '><i class="fa-solid ' + l.icon + '"></i> ' + l.label + '</a></li>';
    }).join('');

    root.innerHTML =
      '<header class="site-header" id="site-header">' +
        '<div class="container nav">' +
          '<a href="index.html" class="brand"><span class="brand-mark"><i class="fa-solid fa-seedling"></i></span>' +
            '<span>ZeroWaste<small>Food Rescue Network</small></span></a>' +
          '<nav aria-label="Main navigation"><ul class="nav-links">' + links + '</ul></nav>' +
          '<div class="nav-actions">' +
            '<button type="button" class="theme-toggle" id="theme-toggle" aria-label="Toggle dark mode" title="Toggle dark / light mode">' +
              '<i class="fa-solid fa-moon"></i><i class="fa-solid fa-sun"></i></button>' +
            sessionArea() +
            '<button type="button" class="nav-toggle" id="nav-toggle" aria-label="Open menu" aria-expanded="false">' +
              '<span></span><span></span><span></span></button>' +
          '</div>' +
        '</div>' +
      '</header>' +
      '<div class="nav-drawer" id="nav-drawer">' +
        '<ul>' + drawerLinks + '</ul>' +
        '<ul>' + drawerExtra() + '</ul>' +
        '<div class="flex" style="flex-direction:column;gap:10px">' +
          '<a href="donate.html" class="btn btn-primary btn-block"><i class="fa-solid fa-hand-holding-heart"></i> Donate Food</a>' +
          '<a href="receive.html" class="btn btn-outline btn-block"><i class="fa-solid fa-bowl-food"></i> Find Food</a>' +
        '</div>' +
      '</div>';
  }

  function renderFooter() {
    var root = ZW.byId('footer-root');
    if (!root) return;
    var year = new Date().getFullYear();
    root.innerHTML =
      '<footer class="site-footer">' +
        '<div class="container">' +
          '<div class="footer-grid">' +
            '<div>' +
              '<a href="index.html" class="brand"><span class="brand-mark"><i class="fa-solid fa-seedling"></i></span>' +
                '<span>ZeroWaste<small>Food Rescue Network</small></span></a>' +
              '<p class="mt-2">A campus-and-community food rescue network that connects surplus food with the people who need it - before it becomes waste.</p>' +
              '<div class="footer-social">' +
                '<a href="#" aria-label="ZeroWaste on X"><i class="fa-brands fa-x-twitter"></i></a>' +
                '<a href="#" aria-label="ZeroWaste on Instagram"><i class="fa-brands fa-instagram"></i></a>' +
                '<a href="#" aria-label="ZeroWaste on LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>' +
                '<a href="#" aria-label="ZeroWaste on GitHub"><i class="fa-brands fa-github"></i></a>' +
              '</div>' +
            '</div>' +
            '<div><h4>Platform</h4><ul>' +
              '<li><a href="donate.html">Donate Food</a></li>' +
              '<li><a href="receive.html">Receive Food</a></li>' +
              '<li><a href="map.html">Food Map</a></li>' +
              '<li><a href="dashboard.html">Dashboard</a></li>' +
            '</ul></div>' +
            '<div><h4>Company</h4><ul>' +
              '<li><a href="about.html">About Us</a></li>' +
              '<li><a href="index.html#how">How It Works</a></li>' +
              '<li><a href="about.html#impact">Impact</a></li>' +
              '<li><a href="index.html#faq">FAQ</a></li>' +
            '</ul></div>' +
            '<div><h4>Stay Updated</h4>' +
              '<p>Get a monthly summary of meals rescued in your city.</p>' +
              '<form class="newsletter" id="newsletter-form" novalidate>' +
                '<label class="sr-only" for="newsletter-email">Email address</label>' +
                '<input type="email" id="newsletter-email" placeholder="you@example.com" required>' +
                '<button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-paper-plane"></i></button>' +
              '</form>' +
            '</div>' +
          '</div>' +
          '<div class="footer-bottom">' +
            '<span>&copy; ' + year + ' ZeroWaste. Frontend demonstration project - all data is stored in your browser.</span>' +
            '<span class="flex"><a href="about.html">Privacy</a><a href="about.html">Terms</a><a href="admin.html">Admin</a></span>' +
          '</div>' +
        '</div>' +
      '</footer>' +
      '<button type="button" class="to-top" id="to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>';
  }

  /* ---------------------------------------------- 11. SHARED CARD RENDERERS */
  /**
   * Renders one donation card. options.showRequest adds the "Request Food"
   * button (Receive page) instead of "View Details" (home page).
   */
  ZW.donationCard = function (d, options) {
    options = options || {};
    var loc = options.location || ZW.getUserLocation();
    var km = ZW.distanceKm(loc, d);
    var fresh = ZW.freshness(d);
    var image = d.image
      ? '<img src="' + ZW.esc(d.image) + '" alt="' + ZW.esc(d.foodName) + '" loading="lazy" ' +
        'onerror="ZW.imgFallback(this)">'
      : '<div class="media-fallback"><i class="fa-solid fa-bowl-food"></i></div>';

    var primaryAction = options.showRequest
      ? '<button type="button" class="btn btn-primary btn-sm" data-request="' + ZW.esc(d.id) + '">' +
        '<i class="fa-solid fa-hand-holding-heart"></i> Request Food</button>'
      : '<a class="btn btn-primary btn-sm" href="receive.html?id=' + encodeURIComponent(d.id) + '">' +
        '<i class="fa-solid fa-hand-holding-heart"></i> Request Food</a>';

    return '<article class="donation-card" data-id="' + ZW.esc(d.id) + '">' +
      '<div class="donation-media">' + image +
        '<div class="badge-row">' + ZW.categoryBadge(d.category) + ZW.priorityBadge(d, loc) + '</div>' +
      '</div>' +
      '<div class="donation-body">' +
        '<div class="donation-title"><h3>' + ZW.esc(d.foodName) + '</h3>' + ZW.statusBadge(d.status) + '</div>' +
        '<div class="donation-meta">' +
          '<div><i class="fa-solid fa-box-open"></i><span>' + ZW.esc(d.quantity + ' ' + d.unit) + '</span></div>' +
          '<div><i class="fa-solid fa-utensils"></i><span>' + ZW.esc(d.servings || 0) + ' servings</span></div>' +
          '<div><i class="fa-solid fa-location-dot"></i><span>' + ZW.esc(d.city) +
            (isNaN(km) ? '' : ' - ' + km + ' km') + '</span></div>' +
          '<div><i class="fa-regular fa-clock"></i><span>' + ZW.esc(ZW.deadlineText(d.pickupDeadline)) + '</span></div>' +
        '</div>' +
        '<div>' +
          '<div class="flex-between" style="margin-bottom:6px;font-size:0.76rem;color:var(--text-soft)">' +
            '<span><i class="fa-solid fa-heart-pulse"></i> Freshness: ' + ZW.esc(fresh.label) + '</span>' +
            '<span>' + fresh.percent + '%</span></div>' +
          '<div class="meter ' + (fresh.tone === 'warn' ? 'is-warn' : fresh.tone === 'danger' ? 'is-danger' : '') + '">' +
            '<i style="width:' + fresh.percent + '%"></i></div>' +
        '</div>' +
        '<div class="donor-line"><i class="fa-solid ' + ZW.donorIcon(d.donorType) + '"></i>' +
          ZW.esc(d.donorName) + ' <span class="badge badge-neutral">' + ZW.esc(d.donorType) + '</span></div>' +
        '<div class="donation-actions">' + primaryAction +
          '<button type="button" class="btn btn-outline btn-sm" data-details="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-circle-info"></i> Details</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  };

  /** Replaces a broken remote image with a branded placeholder. */
  ZW.imgFallback = function (img) {
    var wrap = img.parentNode;
    if (!wrap || !img.replaceWith) return;
    var box = document.createElement('div');
    box.className = 'media-fallback';
    box.innerHTML = '<i class="fa-solid fa-bowl-food"></i>';
    img.replaceWith(box);
  };

  ZW.skeletonCards = function (count) {
    var out = '';
    for (var i = 0; i < (count || 3); i++) {
      out += '<div class="skeleton-card"><div class="sk-line sk-img"></div><div class="skeleton-body">' +
        '<div class="sk-line sk-60"></div><div class="sk-line sk-80"></div><div class="sk-line sk-40"></div>' +
        '</div></div>';
    }
    return out;
  };

  ZW.emptyState = function (title, message, actionHtml) {
    return '<div class="empty-state">' +
      '<div class="empty-icon"><i class="fa-solid fa-bowl-rice"></i></div>' +
      '<h3>' + ZW.esc(title) + '</h3><p>' + ZW.esc(message) + '</p>' +
      (actionHtml || '') + '</div>';
  };

  /** Small helper for the "details" modal used on the list pages. */
  ZW.donationDetailHTML = function (d) {
    var loc = ZW.getUserLocation();
    var p = ZW.priority(d, loc);
    var km = ZW.distanceKm(loc, d);
    var rows = [
      ['Food type', d.foodType],
      ['Diet', CATEGORY_LABEL[d.category] || d.category],
      ['Quantity', d.quantity + ' ' + d.unit],
      ['Estimated servings', String(d.servings)],
      ['Prepared on', ZW.formatDate(d.prepDate)],
      ['Best before', ZW.formatDate(d.expiryDate)],
      ['Pickup deadline', ZW.formatDateTime(d.pickupDeadline)],
      ['Distance', isNaN(km) ? '-' : km + ' km from you'],
      ['Pickup address', d.address + ', ' + d.city],
      ['Donor', d.donorName + ' (' + d.donorType + ')'],
      ['Contact', d.donorPhone + ' - ' + d.donorEmail]
    ];
    var html = '<div class="donation-media" style="height:200px;border-radius:var(--r-md);overflow:hidden;margin-bottom:18px">' +
      (d.image ? '<img src="' + ZW.esc(d.image) + '" alt="' + ZW.esc(d.foodName) + '" onerror="ZW.imgFallback(this)">'
        : '<div class="media-fallback"><i class="fa-solid fa-bowl-food"></i></div>') + '</div>';
    html += '<div class="flex" style="gap:8px;flex-wrap:wrap;margin-bottom:16px">' + ZW.statusBadge(d.status) +
      ZW.categoryBadge(d.category) + ZW.priorityBadge(d, loc) + '</div>';
    html += '<p style="font-size:0.9rem">' + ZW.esc(d.description) + '</p>';
    html += '<table style="min-width:0;font-size:0.84rem"><tbody>';
    rows.forEach(function (r) {
      html += '<tr><td style="width:42%;color:var(--text-soft)">' + r[0] + '</td><td><strong>' + ZW.esc(r[1]) + '</strong></td></tr>';
    });
    html += '</tbody></table>';
    html += '<div class="card" style="margin-top:16px;padding:16px;background:var(--grad-brand-soft);border-color:var(--green-200)">' +
      '<strong style="font-size:0.88rem"><i class="fa-solid fa-wand-magic-sparkles"></i> Simulated AI Insight</strong>' +
      '<p style="margin:8px 0 0;font-size:0.83rem">Rescue Priority Score <strong>' + p.score + '/100</strong> (' + p.level + ') - ' +
      'urgency ' + p.parts.urgency + '/40, volume ' + p.parts.volume + '/25, perishability ' +
      p.parts.perishability + '/20, proximity ' + p.parts.proximity + '/15. Computed with simple rules, not a real model.</p></div>';
    return html;
  };

  /* ------------------------------------------------------- 12. BIND EVENTS */
  function wireHeaderInteractions() {
    var header = ZW.byId('site-header');
    var toggle = ZW.byId('nav-toggle');
    var drawer = ZW.byId('nav-drawer');

    var themeBtn = ZW.byId('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function () {
        var next = ZW.toggleTheme();
        ZW.toast(next === 'dark' ? 'Dark mode enabled' : 'Light mode enabled',
          'Your preference is saved in localStorage.', 'info', 2600);
      });
    }

    if (toggle && drawer) {
      toggle.addEventListener('click', function () {
        var open = drawer.classList.toggle('is-open');
        toggle.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        document.body.classList.toggle('nav-open', open);
      });
      ZW.qsa('a', drawer).forEach(function (a) {
        a.addEventListener('click', function () {
          drawer.classList.remove('is-open');
          toggle.classList.remove('is-open');
          document.body.classList.remove('nav-open');
        });
      });
    }

    var logout = ZW.byId('logout-btn');
    if (logout) {
      logout.addEventListener('click', function () {
        ZW.logout();
        ZW.toast('Signed out', 'You have been logged out of this browser session.', 'info');
        window.setTimeout(function () { window.location.href = 'index.html'; }, 900);
      });
    }

    var toTop = ZW.byId('to-top');
    if (toTop) {
      toTop.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }

    var newsletter = ZW.byId('newsletter-form');
    if (newsletter) {
      newsletter.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = ZW.byId('newsletter-email');
        var value = input ? input.value.trim() : '';
        if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(value)) {
          ZW.toast('Invalid email', 'Please enter a valid email address.', 'error');
          return;
        }
        var list = storeGet(KEYS.newsletter, []);
        list.push({ email: value, at: new Date().toISOString() });
        storeSet(KEYS.newsletter, list);
        input.value = '';
        ZW.toast('Subscribed', 'We will email your monthly rescue summary.', 'success');
      });
    }

    /* Sticky-header shadow + back-to-top visibility on scroll. */
    var onScroll = function () {
      var y = window.scrollY || window.pageYOffset;
      if (header) header.classList.toggle('is-scrolled', y > 12);
      if (toTop) toTop.classList.toggle('is-visible', y > 480);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* Scroll-reveal animation for elements carrying .reveal */
  function wireReveal() {
    var items = ZW.qsa('.reveal');
    if (!items.length) return;
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    items.forEach(function (el) { io.observe(el); });
  }
  ZW.wireReveal = wireReveal;

  /** Animated count-up for stat numbers (<span class="count" data-target="1200">). */
  function wireCounters() {
    var nodes = ZW.qsa('[data-count]');
    if (!nodes.length) return;
    var run = function (el) {
      var target = parseFloat(el.getAttribute('data-count')) || 0;
      var suffix = el.getAttribute('data-suffix') || '';
      var start = performance.now(), dur = 1400;
      var step = function (now) {
        var p = Math.min(1, (now - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        var value = target * eased;
        el.textContent = (target >= 1000 ? Math.round(value).toLocaleString('en-IN') : Math.round(value)) + suffix;
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    if (!('IntersectionObserver' in window)) { nodes.forEach(run); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
      });
    }, { threshold: 0.4 });
    nodes.forEach(function (n) { io.observe(n); });
  }
  ZW.wireCounters = wireCounters;

  /* Accordion (FAQ) - one open at a time. */
  function wireAccordions() {
    ZW.qsa('.accordion-trigger').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var item = btn.closest('.accordion-item');
        var panel = item.querySelector('.accordion-panel');
        var isOpen = item.classList.contains('is-open');
        ZW.qsa('.accordion-item').forEach(function (other) {
          other.classList.remove('is-open');
          var p = other.querySelector('.accordion-panel');
          if (p) p.style.maxHeight = '0px';
        });
        if (!isOpen) {
          item.classList.add('is-open');
          panel.style.maxHeight = panel.scrollHeight + 40 + 'px';
        }
      });
    });
  }

  /* Tabs - any [data-tab="targetId"] switches panels inside .tabs-group. */
  function wireTabs() {
    ZW.qsa('[data-tab]').forEach(function (tab) {
      tab.addEventListener('click', function () {
        var group = tab.closest('.tabs-group') || document;
        ZW.qsa('[data-tab]', group).forEach(function (t) { t.classList.remove('is-active'); });
        ZW.qsa('.tab-panel', group).forEach(function (p) { p.classList.remove('is-active'); });
        tab.classList.add('is-active');
        var panel = ZW.byId(tab.getAttribute('data-tab'));
        if (panel) panel.classList.add('is-active');
      });
    });
  }

  /* Option cards: keep .is-selected in sync with the hidden radio/checkbox. */
  function wireOptionCards() {
    ZW.qsa('.option input').forEach(function (input) {
      var sync = function () {
        var name = input.getAttribute('name');
        if (input.type === 'radio' && name) {
          ZW.qsa('.option input[name="' + name + '"]').forEach(function (i) {
            i.closest('.option').classList.toggle('is-selected', i.checked);
          });
        } else {
          input.closest('.option').classList.toggle('is-selected', input.checked);
        }
      };
      input.addEventListener('change', sync);
      if (input.checked) sync();
    });
  }
  ZW.wireOptionCards = wireOptionCards;

  /** Smooth scrolling for in-page anchors (native CSS handles most cases). */
  function wireSmoothAnchors() {
    ZW.qsa('a[href^="#"]').forEach(function (a) {
      var href = a.getAttribute('href');
      if (!href || href === '#') return;
      a.addEventListener('click', function (e) {
        var target = document.querySelector(href);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        history.replaceState(null, '', href);
      });
    });
  }

  /* Hide the intro loader once everything is ready. */
  function hideLoader() {
    var loader = ZW.byId('page-loader');
    if (!loader) return;
    window.setTimeout(function () { loader.classList.add('is-done'); }, 380);
  }

  /* ---------------------------------------------------------- 13. BOOTSTRAP */
  function boot() {
    ZW.seed();                 // first visit writes the demo dataset
    renderHeader();            // shared navbar + mobile drawer
    renderFooter();            // shared footer + back-to-top button
    wireModalDismiss();
    wireHeaderInteractions();
    wireReveal();
    wireCounters();
    wireAccordions();
    wireTabs();
    wireOptionCards();
    wireSmoothAnchors();
    hideLoader();
    if (!ZW.storageAvailable) {
      ZW.toast('Storage unavailable', 'Your browser blocked localStorage, so demo data will reset on refresh.', 'warn', 7000);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  ZW.boot = boot;
})();

/* ==========================================================================
   ZeroWaste - shared form validation engine
   Declarative: add data-validate="required|email" to any input and call
   ZW.forms.validate(formElement). Errors render inside the closest .field.
   Supported rules: required, email, phone, positive, number, future, past,
   min:N, max:N, match:#otherFieldId
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});
  var forms = {};

  var MSG = {
    required: 'This field is required.',
    email: 'Enter a valid email address.',
    phone: 'Enter a valid phone number (8-15 digits).',
    positive: 'Enter a value greater than zero.',
    number: 'Please enter numbers only.',
    future: 'Please choose a date and time in the future.',
    past: 'Please choose a date that is not in the future.',
    min: 'This value is too small or too short.',
    max: 'Value is too large.',
    match: 'The values do not match.'
  };

  forms.isEmail = function (v) { return /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(v || '').trim()); };
  forms.isPhone = function (v) {
    var digits = String(v || '').replace(/[^\d]/g, '');
    return digits.length >= 8 && digits.length <= 15;
  };

  /** Build a friendly label for messages: data-label > <label> text > field name. */
  function labelFor(input) {
    if (input.getAttribute('data-label')) return input.getAttribute('data-label');
    var field = input.closest('.field');
    var label = field ? field.querySelector('label') : null;
    if (label) return label.textContent.replace('*', '').trim().replace(/:$/, '').toLowerCase();
    return input.name || 'this field';
  }

  function setMessage(input, message) {
    var field = input.closest('.field');
    var box = field ? field.querySelector('.error-msg') : null;
    if (field) field.classList.toggle('has-error', !!message);
    if (box) {
      box.innerHTML = message ? '<i class="fa-solid fa-circle-exclamation"></i> ' + ZW.esc(message) : '';
    }
    input.setAttribute('aria-invalid', message ? 'true' : 'false');
    return !message;
  }

  forms.clear = function (input) { return setMessage(input, ''); };

  /** Force an error onto a field - used for cross-field rules. */
  forms.setError = function (input, message) { return setMessage(input, message); };

  /** Validate one input against its declared rules. Returns true when valid. */
  forms.check = function (input) {
    var rules = (input.getAttribute('data-validate') || '').split('|').filter(Boolean);
    var value = input.type === 'checkbox' ? input.checked : input.value;
    var text = input.type === 'checkbox' ? '' : String(value || '').trim();
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      var name = rule.split(':')[0];
      var arg = rule.split(':')[1];
      var ok = true;
      if (name === 'required') ok = input.type === 'checkbox' ? !!value : text.length > 0;
      else if (name === 'email') ok = !text || forms.isEmail(text);
      else if (name === 'phone') ok = !text || forms.isPhone(text);
      else if (name === 'number') ok = !text || !isNaN(parseFloat(text));
      else if (name === 'positive') ok = !text || (parseFloat(text) > 0);
      else if (name === 'min') {
        /* Numeric rules compare numbers; for text (e.g. passwords) min means length. */
        var minNum = parseFloat(text);
        ok = !text || (isNaN(minNum) ? text.length >= parseFloat(arg) : minNum >= parseFloat(arg));
      }
      else if (name === 'max') ok = !text || (parseFloat(text) <= parseFloat(arg));
      else if (name === 'future') ok = !text || new Date(text).getTime() > Date.now();
      else if (name === 'past') ok = !text || new Date(text).getTime() <= Date.now();
      else if (name === 'match') {
        var other = document.getElementById(String(arg).replace('#', ''));
        ok = !text || (other && other.value === input.value);
      }
      if (!ok) {
        var msg = input.getAttribute('data-error-' + name) || MSG[name] || 'Please check this field.';
        if (name === 'required') msg = 'Please enter ' + labelFor(input) + '.';
        if (name === 'match') msg = 'This does not match ' + labelFor(document.getElementById(String(arg).replace('#', '')) || input) + '.';
        setMessage(input, msg);
        return false;
      }
    }
    return setMessage(input, '');
  };

  /**
   * Validate every [data-validate] input inside a form.
   * Returns { ok, firstInvalid } and focuses + scrolls to the first problem.
   */
  forms.validate = function (form) {
    var inputs = ZW.qsa('[data-validate]', form);
    var firstInvalid = null, ok = true;
    inputs.forEach(function (input) {
      if (input.disabled || input.closest('.hidden')) return;
      /* Skip fields inside an inactive tab panel (e.g. the other register tab). */
      var panel = input.closest('.tab-panel');
      if (panel && !panel.classList.contains('is-active')) return;
      var valid = forms.check(input);
      if (!valid) { ok = false; if (!firstInvalid) firstInvalid = input; }
    });
    if (firstInvalid) {
      firstInvalid.focus({ preventScroll: true });
      firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return { ok: ok, firstInvalid: firstInvalid };
  };

  /* Live feedback: clear an error as soon as the user fixes it. */
  forms.wireLiveValidation = function (root) {
    ZW.qsa('[data-validate]', root || document).forEach(function (input) {
      if (input.getAttribute('data-live') === 'off') return;
      var handler = function () {
        if (input.closest('.field') && input.closest('.field').classList.contains('has-error')) forms.check(input);
      };
      input.addEventListener('input', handler);
      input.addEventListener('change', handler);
      input.addEventListener('blur', function () {
        if (String(input.value || '').trim() || input.type === 'checkbox') forms.check(input);
      });
    });
  };

  /* Show a form-level banner (used by login / donate for submit feedback). */
  forms.banner = function (hostId, message, type) {
    var host = ZW.byId(hostId);
    if (!host) return;
    if (!message) { host.innerHTML = ''; host.classList.add('hidden'); return; }
    host.classList.remove('hidden');
    host.innerHTML = '<div class="card" style="padding:14px 16px;border-radius:var(--r-sm);display:flex;gap:12px;' +
      'align-items:flex-start;background:' + (type === 'error' ? 'rgba(220,38,38,0.08)' : 'rgba(22,163,74,0.1)') + ';' +
      'border-color:' + (type === 'error' ? 'var(--danger)' : 'var(--green-300)') + '">' +
      '<i class="fa-solid ' + (type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check') + '" style="color:' +
      (type === 'error' ? 'var(--danger)' : 'var(--green-600)') + ';margin-top:3px"></i>' +
      '<div><strong style="font-size:0.88rem">' + ZW.esc(message.title || '') + '</strong>' +
      (message.text ? '<p style="margin:3px 0 0;font-size:0.82rem">' + ZW.esc(message.text) + '</p>' : '') +
      '</div></div>';
  };

  ZW.forms = forms;
})();

/* ==========================================================================
   ZeroWaste - global donation actions
   One delegated listener powers the "Details" modal and the "Request Food"
   button on every page, so individual pages do not duplicate this wiring.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});

  /* The details modal markup is created on demand and reused afterwards. */
  function ensureDetailModal() {
    var el = ZW.byId('detail-modal');
    if (el) return el;
    el = document.createElement('div');
    el.className = 'modal-backdrop';
    el.id = 'detail-modal';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    el.setAttribute('aria-hidden', 'true');
    el.setAttribute('aria-labelledby', 'detail-modal-title');
    el.innerHTML =
      '<div class="modal modal-wide">' +
        '<div class="modal-head">' +
          '<div><h3 id="detail-modal-title">Donation details</h3>' +
          '<p>Everything a receiver needs before requesting this food.</p></div>' +
          '<button type="button" class="modal-close" data-close-modal="detail-modal" aria-label="Close details">' +
            '<i class="fa-solid fa-xmark"></i></button>' +
        '</div>' +
        '<div id="detail-modal-body"></div>' +
      '</div>';
    document.body.appendChild(el);
    return el;
  }

  ZW.openDetails = function (id) {
    var donation = ZW.getDonations().filter(function (d) { return d.id === id; })[0];
    if (!donation) {
      ZW.toast('Donation not found', 'This donation may have been removed.', 'warn');
      return;
    }
    ensureDetailModal();
    ZW.byId('detail-modal-body').innerHTML = ZW.donationDetailHTML(donation);
    ZW.openModal('detail-modal');
  };

  document.addEventListener('click', function (e) {
    var detailsBtn = e.target.closest('[data-details]');
    if (detailsBtn) { ZW.openDetails(detailsBtn.getAttribute('data-details')); return; }

    var requestBtn = e.target.closest('[data-request]');
    if (requestBtn && !ZW.handlesRequest) {
      /* On pages without the receive modal, send the user to the Receive page. */
      window.location.href = 'receive.html?id=' + encodeURIComponent(requestBtn.getAttribute('data-request'));
    }
  });
})();
