/* ==========================================================================
   ZeroWaste - donations.js
   Powers donate.html: live servings estimation, freshness + rescue priority
   previews, image preview, full validation and localStorage persistence.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});

  /* Approximate coordinates so every donation can appear on the Food Map.
     A frontend-only demo has no GPS lookup, so we offset from the city centre. */
  var CITY_COORDS = {
    'Hyderabad': { lat: 17.3850, lng: 78.4867 },
    'Bengaluru': { lat: 12.9716, lng: 77.5946 },
    'Mumbai': { lat: 19.0760, lng: 72.8777 },
    'Delhi': { lat: 28.6139, lng: 77.2090 },
    'Chennai': { lat: 13.0827, lng: 80.2707 },
    'Pune': { lat: 18.5204, lng: 73.8567 }
  };

  var servedImage = null;   // data URL of the uploaded photo
  var servingsManual = false; // true once the donor types their own serving count

  function jitter(base) { return Math.round((base + (Math.random() - 0.5) * 0.09) * 10000) / 10000; }

  function nextDonationId() {
    var all = ZW.getDonations();
    var max = 1000;
    all.forEach(function (d) {
      var n = parseInt(String(d.id).replace(/\D/g, ''), 10);
      if (!isNaN(n) && n > max) max = n;
    });
    return 'ZWD-' + (max + 1);
  }

  function value(id) {
    var el = ZW.byId(id);
    return el ? String(el.value).trim() : '';
  }
  function checkedValue(name) {
    var el = document.querySelector('input[name="' + name + '"]:checked');
    return el ? el.value : '';
  }

  /* ------------------------------------------------- 1. LIVE CALCULATIONS */
  /**
   * Recomputes the "Simulated AI" panel from the current form values:
   *   - estimated servings (quantity -> meals)
   *   - freshness index of the food as it will be listed
   *   - rescue priority score for the new listing
   */
  function recalc() {
    var quantity = value('quantity');
    var unit = value('unit') || 'kg';
    var foodType = value('food-type') || 'Cooked Meal';
    var category = checkedValue('category') || 'veg';

    var estimate = ZW.estimateServings(quantity, unit, foodType, category);
    var servingsInput = ZW.byId('servings');
    if (servingsInput && !servingsManual) servingsInput.value = estimate || '';

    var shownServings = parseInt(String(servingsInput ? servingsInput.value : estimate), 10) || estimate || 0;
    var servingsOut = ZW.byId('calc-servings');
    if (servingsOut) servingsOut.textContent = shownServings ? shownServings : '-';

    var mealsOut = ZW.byId('calc-meals');
    /* Roughly four servings per household meal - a friendlier framing. */
    if (mealsOut) mealsOut.textContent = shownServings ? Math.max(1, Math.ceil(shownServings / 4)) : '-';

    /* Freshness preview using the dates currently entered. */
    var draft = {
      prepDate: value('prep-date') || ZW.localStamp(new Date()).slice(0, 10),
      expiryDate: value('expiry-date') || ZW.localStamp(new Date(Date.now() + 12 * 3600000)).slice(0, 10),
      pickupDeadline: value('pickup-deadline'),
      foodType: foodType,
      servings: shownServings,
      category: category,
      lat: (CITY_COORDS[value('city')] || ZW.DEFAULT_LOCATION).lat,
      lng: (CITY_COORDS[value('city')] || ZW.DEFAULT_LOCATION).lng
    };
    var fresh = ZW.freshness(draft);
    var freshOut = ZW.byId('calc-freshness');
    var freshBar = ZW.byId('calc-freshness-bar');
    if (freshOut) freshOut.textContent = fresh.label;
    if (freshBar) {
      freshBar.className = 'meter ' + (fresh.tone === 'warn' ? 'is-warn' : fresh.tone === 'danger' ? 'is-danger' : '');
      freshBar.innerHTML = '<i style="width:' + fresh.percent + '%"></i>';
    }
    var freshPercent = ZW.byId('calc-freshness-percent');
    if (freshPercent) freshPercent.textContent = fresh.percent + '%';

    var priority = ZW.priority(draft);
    var prioOut = ZW.byId('calc-priority');
    var prioNote = ZW.byId('calc-priority-note');
    if (prioOut) {
      prioOut.textContent = priority.level;
      prioOut.style.color = priority.level === 'High' ? 'var(--danger)'
        : priority.level === 'Medium' ? 'var(--warning)' : 'var(--green-700)';
    }
    if (prioNote) {
      prioNote.textContent = 'Score ' + priority.score + '/100 - urgency ' + priority.parts.urgency +
        ', volume ' + priority.parts.volume + ', perishability ' + priority.parts.perishability +
        ', proximity ' + priority.parts.proximity;
    }
    var estNote = ZW.byId('estimation-note');
    if (estNote) {
      estNote.textContent = shownServings
        ? 'Estimate: about ' + shownServings + ' servings from ' + quantity + ' ' + unit +
          ' of ' + foodType.toLowerCase() + '. You can edit this number.'
        : 'Enter a quantity to see the automatic serving estimate.';
    }
  }

  /* ---------------------------------------------------- 2. IMAGE PREVIEW */
  /* Photographs are downscaled with a canvas before saving. localStorage only
     holds a few megabytes, so storing a full-resolution photo would fill the
     quota and silently break every later write. */
  function downscale(dataUrl, done) {
    var image = new Image();
    image.onload = function () {
      var max = 900;
      var scale = Math.min(1, max / Math.max(image.width, image.height));
      var canvas = document.createElement('canvas');
      canvas.width = Math.round(image.width * scale) || max;
      canvas.height = Math.round(image.height * scale) || max;
      canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
      try { done(canvas.toDataURL('image/jpeg', 0.72)); } catch (err) { done(dataUrl); }
    };
    image.onerror = function () { done(dataUrl); };
    image.src = dataUrl;
  }

  function wireImagePreview() {
    var input = ZW.byId('food-image');
    var box = ZW.byId('image-preview');
    var img = ZW.byId('preview-img');
    var meta = ZW.byId('preview-meta');
    var removeBtn = ZW.byId('preview-remove');
    if (!input || !box) return;

    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) return;
      if (!/^image\//.test(file.type)) {
        ZW.toast('Unsupported file', 'Please choose a JPG, PNG or WEBP image.', 'error');
        input.value = '';
        return;
      }
      if (file.size > 6 * 1024 * 1024) {
        ZW.toast('Image too large', 'Please pick an image smaller than 6 MB.', 'warn');
        input.value = '';
        return;
      }
      var reader = new FileReader();
      reader.onload = function (e) {
        downscale(e.target.result, function (dataUrl) {
          servedImage = dataUrl;
          img.src = servedImage;
          box.classList.add('is-visible');
          if (meta) meta.textContent = file.name + ' - saved as a ' + Math.round(dataUrl.length / 1024) + ' KB thumbnail';
        });
      };
      reader.readAsDataURL(file);
    });

    if (removeBtn) {
      removeBtn.addEventListener('click', function () {
        servedImage = null;
        input.value = '';
        box.classList.remove('is-visible');
        img.removeAttribute('src');
      });
    }
  }

  /* -------------------------------------------------- 3. SAVE + RENDER LIST */
  /** Renders the donations created in this browser (newest first). */
  function renderMyDonations() {
    var host = ZW.byId('my-donations');
    if (!host) return;
    var pool = ZW.getDonations();
    var session = ZW.getSession();
    if (session && session.email) {
      var mine = pool.filter(function (d) {
        return d.donorEmail && d.donorEmail.toLowerCase() === String(session.email).toLowerCase();
      });
      if (mine.length) pool = mine;
    }
    var all = pool.slice().sort(function (a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    }).slice(0, 6);

    if (!all.length) {
      host.innerHTML = ZW.emptyState('No donations yet',
        'Your submitted donations will appear here with their live status.',
        '<a class="btn btn-primary" href="receive.html"><i class="fa-solid fa-bowl-food"></i> Browse available food</a>');
      return;
    }

    host.innerHTML = '<div class="grid grid-auto">' + all.map(function (d) {
      return ZW.donationCard(d, { showRequest: false });
    }).join('') + '</div>';
    ZW.wireReveal();
  }

  function buildDonation() {
    var city = value('city') || 'Hyderabad';
    var base = CITY_COORDS[city] || ZW.DEFAULT_LOCATION;
    return {
      id: nextDonationId(),
      foodName: value('food-name'),
      foodType: value('food-type'),
      category: checkedValue('category') || 'veg',
      quantity: parseFloat(value('quantity')) || 0,
      unit: value('unit') || 'kg',
      servings: parseInt(value('servings'), 10) || ZW.estimateServings(value('quantity'), value('unit'), value('food-type'), checkedValue('category')),
      prepDate: value('prep-date'),
      expiryDate: value('expiry-date'),
      pickupDeadline: value('pickup-deadline'),
      address: value('address'),
      city: city,
      lat: jitter(base.lat),
      lng: jitter(base.lng),
      description: value('description'),
      image: servedImage || '',
      donorName: value('donor-name'),
      donorType: value('donor-type') || 'Household',
      donorEmail: value('donor-email'),
      donorPhone: value('donor-phone'),
      status: 'Pending',
      createdAt: new Date().toISOString()
    };
  }

  function wireSubmit() {
    var form = ZW.byId('donate-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      ZW.forms.banner('donate-alert', null);
      var result = ZW.forms.validate(form);
      if (!result.ok) {
        ZW.toast('Please fix the highlighted fields', 'Some required details are missing or invalid.', 'error');
        return;
      }

      /* The diet radios are a group, so check them explicitly. */
      if (!checkedValue('category')) {
        var group = document.querySelector('.option-group');
        if (group) group.scrollIntoView({ behavior: 'smooth', block: 'center' });
        ZW.toast('Choose a food category', 'Select Vegetarian, Non-Vegetarian or Vegan.', 'error');
        return;
      }

      /* Extra cross-field checks that the declarative rules cannot express. */
      var prep = new Date(value('prep-date')).getTime();
      var expiry = new Date(value('expiry-date')).getTime();
      var deadline = new Date(value('pickup-deadline')).getTime();
      if (expiry <= prep) {
        ZW.forms.setError(ZW.byId('expiry-date'),
          'The best-before date must be after the preparation date.');
        ZW.toast('Check your dates', 'Food cannot expire before it was prepared.', 'error');
        return;
      }
      if (deadline > expiry) {
        ZW.toast('Check the pickup deadline', 'The pickup deadline should be before the food expires.', 'warn', 6000);
      }

      var submit = form.querySelector('button[type="submit"]');
      submit.classList.add('is-loading');

      window.setTimeout(function () {
        submit.classList.remove('is-loading');
        var donation = buildDonation();
        var all = ZW.getDonations();
        all.push(donation);
        var persisted = ZW.saveDonations(all);
        if (!persisted) {
          ZW.toast('Browser storage is full', 'The donation was kept for this session only. Try clearing site data or using a smaller photo.', 'warn', 8000);
        }
        ZW.logActivity('New donation listed: ' + donation.foodName + ' (' + donation.servings + ' servings)', 'fa-hand-holding-heart');

        var priority = ZW.priority(donation);
        ZW.forms.banner('donate-alert', {
          title: 'Donation ' + donation.id + ' submitted successfully!',
          text: donation.servings + ' estimated servings are now visible to receivers. Rescue priority: ' +
            priority.level + ' (' + priority.score + '/100).'
        }, 'success');
        ZW.toast('Donation saved', donation.id + ' is now listed on the Receive Food page.', 'success', 6000);

        form.reset();
        servedImage = null;
        servingsManual = false;
        var preview = ZW.byId('image-preview');
        if (preview) preview.classList.remove('is-visible');
        ZW.qsa('.option input').forEach(function (i) { i.closest('.option').classList.remove('is-selected'); });
        setDefaultDates();
        recalc();
        renderMyDonations();
        ZW.byId('donate-alert').scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 700);
    });
  }

  /* Sensible defaults: prepared now, expires in 12 hours, pickup in 6 hours. */
  function setDefaultDates() {
    var prep = ZW.byId('prep-date');
    var expiry = ZW.byId('expiry-date');
    var deadline = ZW.byId('pickup-deadline');
    if (prep && !prep.value) prep.value = ZW.localStamp(new Date()).slice(0, 10);
    if (expiry && !expiry.value) expiry.value = ZW.localStamp(new Date(Date.now() + 12 * 3600000)).slice(0, 10);
    if (deadline && !deadline.value) deadline.value = ZW.localStamp(new Date(Date.now() + 6 * 3600000));
    /* Keep the date pickers from accepting impossible values. */
    if (prep) prep.setAttribute('max', ZW.localStamp(new Date()).slice(0, 10));
    if (expiry) expiry.setAttribute('min', ZW.localStamp(new Date()).slice(0, 10));
  }

  /* ------------------------------------------------------------- 4. INIT */
  function init() {
    var form = ZW.byId('donate-form');
    if (!form) return;

    setDefaultDates();
    wireImagePreview();
    wireSubmit();
    ZW.forms.wireLiveValidation(form);

    /* Live recalculation on every relevant field change. */
    ['quantity', 'unit', 'food-type', 'category', 'prep-date', 'expiry-date', 'pickup-deadline', 'city']
      .forEach(function (id) {
        var el = ZW.byId(id);
        if (el) { el.addEventListener('input', recalc); el.addEventListener('change', recalc); }
      });
    ZW.qsa('input[name="category"]').forEach(function (el) { el.addEventListener('change', recalc); });

    var servings = ZW.byId('servings');
    if (servings) {
      servings.addEventListener('input', function () {
        servingsManual = servings.value !== ''; // manual value wins from now on
        recalc();
      });
    }
    var resetBtn = ZW.byId('recalc-servings');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        servingsManual = false;
        recalc();
        ZW.toast('Estimate restored', 'The automatic serving estimate has been recalculated.', 'info', 2400);
      });
    }

    var clearBtn = ZW.byId('clear-form');
    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        form.reset();
        servedImage = null;
        servingsManual = false;
        var preview = ZW.byId('image-preview');
        if (preview) preview.classList.remove('is-visible');
        ZW.qsa('.option input').forEach(function (i) { i.closest('.option').classList.remove('is-selected'); });
        ZW.qsa('[data-validate]').forEach(function (i) { ZW.forms.clear(i); });
        ZW.forms.banner('donate-alert', null);
        setDefaultDates();
        recalc();
        ZW.toast('Form cleared', 'All fields have been reset.', 'info', 2200);
      });
    }

    recalc();
    renderMyDonations();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
