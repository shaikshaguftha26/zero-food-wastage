/* ==========================================================================
   ZeroWaste - auth.js
   Simulated authentication for the frontend demo.
   NOTE: this is NOT real security. Accounts live in localStorage in plain
   text so a college demo can show donor / receiver / admin flows offline.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});
  var auth = (ZW.auth = {});

  auth.currentUser = function () { return ZW.getSession(); };

  auth.findUser = function (email) {
    var target = String(email || '').trim().toLowerCase();
    return ZW.getUsers().filter(function (u) { return String(u.email).toLowerCase() === target; })[0] || null;
  };

  /** Sends the visitor to the login page when they are not signed in. */
  auth.requireSession = function (role) {
    var s = ZW.getSession();
    if (!s) {
      ZW.toast('Please sign in', 'You need an account to open that page.', 'warn');
      window.setTimeout(function () { window.location.href = 'login.html'; }, 1000);
      return null;
    }
    if (role && s.role !== role) {
      ZW.toast('Access restricted', 'This page is for ' + role + ' accounts only.', 'error');
      window.setTimeout(function () { window.location.href = 'dashboard.html'; }, 1200);
      return null;
    }
    return s;
  };

  function rememberMe(remember, email) {
    if (remember) {
      ZW.storeSet(ZW.KEYS.remembered, { email: email });
    } else {
      try { window.localStorage.removeItem(ZW.KEYS.remembered); } catch (e) { /* ignore */ }
    }
  }

  /* ------------------------------------------------------------- LOGIN PAGE */
  function initLogin() {
    var form = ZW.byId('login-form');
    if (!form) return;

    /* Pre-fill the "remember me" email from a previous visit. */
    var remembered = ZW.storeGet(ZW.KEYS.remembered, null);
    if (remembered && remembered.email) {
      ZW.byId('login-email').value = remembered.email;
      ZW.byId('login-remember').checked = true;
    }

    /* Quick-fill demo accounts - keeps the classroom demo fast. */
    ZW.qsa('.demo-fill').forEach(function (btn) {
      btn.addEventListener('click', function () {
        ZW.byId('login-email').value = btn.getAttribute('data-email');
        ZW.byId('login-password').value = btn.getAttribute('data-password');
        ZW.forms.clear(ZW.byId('login-email'));
        ZW.forms.clear(ZW.byId('login-password'));
        ZW.toast('Demo credentials filled', 'Press "Sign In" to continue.', 'info', 2200);
      });
    });

    ZW.forms.wireLiveValidation(form);

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      ZW.forms.banner('login-alert', null);
      if (!ZW.forms.validate(form).ok) return;

      var email = ZW.byId('login-email').value;
      var password = ZW.byId('login-password').value;
      var remember = ZW.byId('login-remember').checked;
      var submit = form.querySelector('button[type="submit"]');
      submit.classList.add('is-loading');

      /* Small delay so the loading state is visible, then "authenticate". */
      window.setTimeout(function () {
        submit.classList.remove('is-loading');
        var user = auth.findUser(email);

        if (!user || user.password !== password) {
          ZW.forms.banner('login-alert', { title: 'Invalid email or password',
            text: 'Use one of the demo accounts listed below if you are just exploring.' }, 'error');
          ZW.toast('Sign in failed', 'Check your email and password and try again.', 'error');
          return;
        }
        if (user.status === 'Pending Verification') {
          ZW.forms.banner('login-alert', { title: 'Account pending verification',
            text: 'An administrator must approve this account before you can sign in.' }, 'error');
          return;
        }

        ZW.saveSession({ id: user.id, name: user.name, email: user.email, role: user.role,
          org: user.org, city: user.city, donorType: user.donorType, at: new Date().toISOString() });
        rememberMe(remember, user.email);
        ZW.logActivity(user.name + ' signed in', 'fa-right-to-bracket');
        ZW.forms.banner('login-alert', { title: 'Welcome back, ' + user.name.split(' ')[0] + '!',
          text: 'Redirecting you to your dashboard...' }, 'success');
        ZW.toast('Signed in', 'Welcome back to ZeroWaste.', 'success');
        window.setTimeout(function () {
          window.location.href = user.role === 'admin' ? 'admin.html' : 'dashboard.html';
        }, 1100);
      }, 620);
    });

    initForgotPassword();
  }

  /* Forgot password: purely a frontend simulation, no email is sent. */
  function initForgotPassword() {
    var form = ZW.byId('forgot-form');
    if (!form) return;
    ZW.byId('forgot-open').addEventListener('click', function (e) {
      e.preventDefault();
      ZW.openModal('forgot-modal');
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!ZW.forms.validate(form).ok) return;
      var email = ZW.byId('forgot-email').value;
      var user = auth.findUser(email);
      ZW.closeModal('forgot-modal');
      if (user) {
        ZW.toast('Reset link "sent"', 'Demo mode: no email is really sent. Your password is ' + user.password + '.', 'info', 7000);
      } else {
        ZW.toast('Check your inbox', 'If that email exists we would have sent a reset link.', 'info', 5000);
      }
      form.reset();
    });
  }

  /* ---------------------------------------------------------- REGISTER PAGE */
  /** Reads the registration form and stores a simulated account. */
  function handleRegister(form, role) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var alertId = role === 'donor' ? 'donor-alert' : 'receiver-alert';
      ZW.forms.banner(alertId, null);
      if (!ZW.forms.validate(form).ok) return;

      var prefix = role === 'donor' ? 'd' : 'r';
      var email = ZW.byId(prefix + '-email').value.trim();
      if (auth.findUser(email)) {
        ZW.forms.banner(alertId, { title: 'Email already registered',
          text: 'Try signing in instead, or use a different email address.' }, 'error');
        return;
      }

      var submit = form.querySelector('button[type="submit"]');
      submit.classList.add('is-loading');

      window.setTimeout(function () {
        submit.classList.remove('is-loading');
        var users = ZW.getUsers();
        /* Highest existing numeric id + 1, so deleting a user never reuses an id. */
        var maxId = 0;
        users.forEach(function (u) {
          var n = parseInt(String(u.id).replace(/\D/g, ''), 10);
          if (!isNaN(n) && n > maxId) maxId = n;
        });
        var user = {
          id: 'ZWU-' + String(maxId + 1).padStart(3, '0'),
          name: ZW.byId(prefix + '-name').value.trim(),
          email: email,
          password: ZW.byId(prefix + '-password').value,
          role: role,
          org: ZW.byId(prefix + '-org').value.trim() || (role === 'receiver' ? 'Independent Receiver' : 'Household'),
          phone: ZW.byId(prefix + '-phone').value.trim(),
          city: ZW.byId(prefix + '-city').value,
          donorType: role === 'donor' ? ZW.byId('d-donor-type').value : undefined,
          /* Receiver-only extras (guarded so the donor form never looks them up). */
          receiverType: role === 'receiver' ? ZW.byId('r-type').value : undefined,
          capacity: role === 'receiver' ? (parseInt(ZW.byId('r-capacity').value, 10) || 0) : undefined,
          status: role === 'receiver' ? 'Pending Verification' : 'Active',
          joinedAt: new Date().toISOString()
        };
        users.push(user);
        ZW.saveUsers(users);
        ZW.logActivity('New ' + role + ' registered: ' + user.name, 'fa-user-plus');

        ZW.forms.banner(alertId, { title: 'Registration successful',
          text: role === 'receiver'
            ? 'Your NGO/volunteer account is awaiting admin verification. You can still browse the Receive Food page.'
            : 'Your donor account is ready. Sign in to start donating surplus food.' }, 'success');
        ZW.toast('Account created', 'Saved to localStorage as ' + user.id, 'success');
        form.reset();
        ZW.qsa('.option input', form).forEach(function (i) { i.closest('.option').classList.remove('is-selected'); });

        window.setTimeout(function () { window.location.href = 'login.html'; }, 2200);
      }, 700);
    });
  }

  /* Rule-based password strength hint. Any password input carrying a
     data-meter="<elementId>" attribute gets its own live meter. */
  function initPasswordMeter() {
    var inputs = ZW.qsa('input[type="password"][data-meter]');
    if (!inputs.length) return;
    var labels = ['Too short', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
    var colors = ['var(--danger)', 'var(--danger)', 'var(--warning)', 'var(--warning)', 'var(--green-600)', 'var(--green-600)'];

    inputs.forEach(function (input) {
      var meter = ZW.byId(input.getAttribute('data-meter'));
      if (!meter) return;
      var update = function (value) {
        var score = 0;
        if (value.length >= 6) score++;
        if (value.length >= 10) score++;
        if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
        if (/\d/.test(value)) score++;
        if (/[^A-Za-z0-9]/.test(value)) score++;
        meter.innerHTML = '<div class="meter ' + (score <= 2 ? 'is-danger' : score === 3 ? 'is-warn' : '') + '">' +
          '<i style="width:' + Math.min(100, score * 20) + '%"></i></div>' +
          '<small style="font-size:0.74rem;color:' + colors[score] + '">Password strength: ' + labels[score] + '</small>';
      };
      input.addEventListener('input', function () { update(input.value); });
      update(input.value || '');
    });
  }

  function initRegister() {
    var donorForm = ZW.byId('register-donor-form');
    var receiverForm = ZW.byId('register-receiver-form');
    if (donorForm) { handleRegister(donorForm, 'donor'); ZW.forms.wireLiveValidation(donorForm); }
    if (receiverForm) { handleRegister(receiverForm, 'receiver'); ZW.forms.wireLiveValidation(receiverForm); }
    if (donorForm || receiverForm) initPasswordMeter();
  }

  /* --------------------------------------------------------------- BOOTSTRAP */
  function init() {
    initLogin();
    initRegister();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
