/* ==========================================================================
   ZeroWaste - dashboard.js
   Role-aware dashboard: donors track their listings and status flow, receivers
   track requests, matches and pickups. Charts are pure CSS, no libraries.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});

  var session = null;
  var donations = [];
  var requests = [];

  function num(el, value) { if (el) el.textContent = value; }

  /* ------------------------------------------------------------- 1. SCRAP */
  function myDonations() {
    if (!session) return [];
    return donations.filter(function (d) {
      return d.donorEmail && d.donorEmail.toLowerCase() === String(session.email).toLowerCase();
    });
  }
  function myRequests() {
    if (!session) return [];
    return requests.filter(function (r) {
      return r.orgName === session.org || r.receiverName === session.name;
    });
  }
  function donationById(id) {
    return donations.filter(function (d) { return d.id === id; })[0] || null;
  }

  /* ---------------------------------------------------------- 2. KPI CARDS */
  function kpi(icon, tone, value, label, trend, down) {
    /* Animate a leading number with the shared counter, keep any suffix as text. */
    var str = String(value);
    var m = str.match(/^(\d[\d,]*)(.*)$/);
    var valueHtml = m
      ? '<span data-count="' + m[1].replace(/,/g, '') + '">0</span>' + ZW.esc(m[2])
      : ZW.esc(str);
    return '<div class="kpi">' +
      '<div class="kpi-icon" style="background:' + tone + '"><i class="fa-solid ' + icon + '"></i></div>' +
      '<div class="kpi-value">' + valueHtml + '</div>' +
      '<div class="kpi-label">' + ZW.esc(label) + '</div>' +
      (trend ? '<div class="kpi-trend' + (down ? ' down' : '') + '">' + trend + '</div>' : '') +
    '</div>';
  }

  function renderDonorKpis() {
    var mine = myDonations();
    var active = mine.filter(function (d) { return d.status !== 'Completed' && d.status !== 'Rejected'; });
    var done = mine.filter(function (d) { return d.status === 'Completed'; });
    var meals = mine.reduce(function (s, d) { return s + (Number(d.servings) || 0); }, 0);
    var kg = mine.reduce(function (s, d) { return s + (Number(d.quantity) || 0); }, 0);

    var host = ZW.byId('dash-kpis');
    if (!host) return;
    host.innerHTML =
      kpi('fa-hand-holding-heart', 'linear-gradient(135deg,#16a34a,#4ade80)', mine.length, 'Total donations', 'All time', false) +
      kpi('fa-hourglass-half', 'linear-gradient(135deg,#d97706,#fbbf24)', active.length, 'Active donations', 'Awaiting pickup', false) +
      kpi('fa-circle-check', 'linear-gradient(135deg,#2563eb,#60a5fa)', done.length, 'Completed rescues', 'Delivered to NGOs', false) +
      kpi('fa-utensils', 'linear-gradient(135deg,#7c3aed,#a78bfa)', meals, 'Meals offered', 'Estimated servings', false) +
      kpi('fa-weight-hanging', 'linear-gradient(135deg,#0f766e,#2dd4bf)', Math.round(kg) + ' kg', 'Food saved', 'Total volume', false);
  }

  function renderReceiverKpis() {
    var mine = myRequests();
    var available = donations.filter(function (d) { return d.status === 'Pending'; });
    var accepted = mine.filter(function (r) { return r.status === 'Accepted'; });
    var completed = mine.filter(function (r) { return r.status === 'Completed'; });
    var received = completed.reduce(function (s, r) { return s + (Number(r.servings) || 0); }, 0);

    var host = ZW.byId('dash-kpis');
    if (!host) return;
    host.innerHTML =
      kpi('fa-bowl-food', 'linear-gradient(135deg,#16a34a,#4ade80)', available.length, 'Available now', 'Across all cities', false) +
      kpi('fa-paper-plane', 'linear-gradient(135deg,#2563eb,#60a5fa)', mine.length, 'Requests made', 'All time', false) +
      kpi('fa-thumbs-up', 'linear-gradient(135deg,#d97706,#fbbf24)', accepted.length, 'Accepted requests', 'Ready to schedule', false) +
      kpi('fa-truck-fast', 'linear-gradient(135deg,#7c3aed,#a78bfa)', completed.length, 'Completed pickups', 'Delivered', false) +
      kpi('fa-utensils', 'linear-gradient(135deg,#0f766e,#2dd4bf)', received, 'Meals received', 'Estimated servings', false);
  }

  /* --------------------------------------------------------- 3. CSS CHARTS */
  /** Simple bar chart: rows = [{label, value}] */
  function renderBarChart(hostId, rows, valueLabel) {
    var host = ZW.byId(hostId);
    if (!host) return;
    var max = Math.max(1, rows.reduce(function (m, r) { return Math.max(m, r.value); }, 0));
    host.innerHTML = '<div class="bar-chart">' + rows.map(function (r) {
      var height = Math.max(4, Math.round((r.value / max) * 100));
      return '<div class="bar-col" title="' + ZW.esc(r.label + ': ' + r.value + ' ' + valueLabel) + '">' +
        '<div class="bar" data-value="' + r.value + '" style="height:' + height + '%"></div>' +
        '<span class="bar-label">' + ZW.esc(r.label) + '</span>' +
      '</div>';
    }).join('') + '</div>';
  }

  function lastSixMonths() {
    var months = [];
    for (var i = 5; i >= 0; i--) {
      var d = new Date();
      d.setMonth(d.getMonth() - i);
      d.setDate(1);
      months.push({ key: d.getFullYear() + '-' + ZW.pad(d.getMonth() + 1), label: d.toLocaleString('en-IN', { month: 'short' }) });
    }
    return months;
  }

  function renderDonorCharts() {
    var mine = myDonations();
    var months = lastSixMonths();
    var rows = months.map(function (m) {
      var count = mine.filter(function (d) {
        return String(d.createdAt || d.prepDate).slice(0, 7) === m.key;
      }).length;
      return { label: m.label, value: count };
    });
    renderBarChart('chart-donations', rows, 'donations');

    /* Donut: status distribution of this donor's listings. */
    var groups = [
      { label: 'Pending', color: '#d97706', value: mine.filter(function (d) { return d.status === 'Pending'; }).length },
      { label: 'In progress', color: '#2563eb', value: mine.filter(function (d) {
          return ['Accepted', 'Pickup Scheduled', 'Picked Up'].indexOf(d.status) !== -1; }).length },
      { label: 'Completed', color: '#16a34a', value: mine.filter(function (d) { return d.status === 'Completed'; }).length },
      { label: 'Delivered', color: '#7c3aed', value: mine.filter(function (d) { return d.status === 'Delivered'; }).length }
    ];
    renderDonut('chart-status', groups, mine.length, 'donations');
  }

  function renderReceiverCharts() {
    var mine = myRequests();
    var months = lastSixMonths();
    renderBarChart('chart-donations', months.map(function (m) {
      return { label: m.label, value: mine.filter(function (r) { return String(r.createdAt).slice(0, 7) === m.key; }).length };
    }), 'requests');

    var groups = [
      { label: 'Pending', color: '#d97706', value: mine.filter(function (r) { return r.status === 'Pending'; }).length },
      { label: 'Accepted', color: '#2563eb', value: mine.filter(function (r) { return r.status === 'Accepted'; }).length },
      { label: 'Completed', color: '#16a34a', value: mine.filter(function (r) { return r.status === 'Completed'; }).length }
    ];
    renderDonut('chart-status', groups, mine.length, 'requests');
  }

  /** Conic-gradient donut - no chart library required. */
  function renderDonut(hostId, groups, total, unitLabel) {
    var host = ZW.byId(hostId);
    if (!host) return;
    var sum = groups.reduce(function (s, g) { return s + g.value; }, 0);
    var angle = 0;
    var stops = [];
    groups.forEach(function (g) {
      if (!g.value || !sum) return;
      var slice = (g.value / sum) * 360;
      stops.push(g.color + ' ' + angle + 'deg ' + (angle + slice) + 'deg');
      angle += slice;
    });
    var gradient = stops.length ? 'conic-gradient(' + stops.join(', ') + ')' : 'conic-gradient(var(--border) 0deg 360deg)';

    host.innerHTML = '<div class="donut-wrap">' +
      '<div class="donut" style="background:' + gradient + '">' +
        '<div class="donut-center"><strong>' + (sum ? sum : 0) + '</strong><small>' + ZW.esc(unitLabel) + '</small></div>' +
      '</div>' +
      '<div class="legend">' + groups.map(function (g) {
        return '<div class="legend-item"><span class="swatch" style="background:' + g.color + '"></span>' +
          ZW.esc(g.label) + '<b>' + g.value + '</b></div>';
      }).join('') + '</div>' +
    '</div>';
  }

  /* ------------------------------------------------------- 4. STATUS TABLES */
  /** Visual flow of the donation lifecycle, highlighting reached states. */
  function statusFlow(current) {
    var index = ZW.STATUS_FLOW.indexOf(current);
    return '<div class="status-flow">' + ZW.STATUS_FLOW.map(function (s, i) {
      var done = index >= 0 && i <= index;
      return '<span class="node' + (done ? ' done' : '') + '">' +
        (done ? '<i class="fa-solid fa-check"></i> ' : '') + ZW.esc(s) + '</span>' +
        (i < ZW.STATUS_FLOW.length - 1 ? '<i class="fa-solid fa-arrow-right arrow"></i>' : '');
    }).join('') + '</div>';
  }

  /** Moves a donation one step further along the status flow. */
  function advanceStatus(id) {
    var all = ZW.getDonations();
    var target = all.filter(function (d) { return d.id === id; })[0];
    if (!target) return;
    var next = ZW.STATUS_FLOW[Math.min(ZW.STATUS_FLOW.indexOf(target.status) + 1, ZW.STATUS_FLOW.length - 1)];
    if (next === target.status) {
      ZW.toast('Already completed', 'This donation has reached the end of the flow.', 'info');
      return;
    }
    target.status = next;
    ZW.saveDonations(all);
    ZW.logActivity(id + ' moved to "' + next + '"', 'fa-arrow-right-arrow-left');
    ZW.toast('Status updated', id + ' is now "' + next + '".', 'success');
    refresh();
  }

  function renderDonorTable() {
    var host = ZW.byId('dash-table');
    if (!host) return;
    var mine = myDonations().sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
    var title = ZW.byId('dash-table-title');
    if (title) title.textContent = 'Your donation history';

    if (!mine.length) {
      host.innerHTML = ZW.emptyState('No donations yet',
        'Create your first listing and it will appear here with a live status flow.',
        '<a class="btn btn-primary" href="donate.html"><i class="fa-solid fa-hand-holding-heart"></i> Donate food</a>');
      return;
    }

    var rows = mine.map(function (d) {
      var last = ZW.STATUS_FLOW[ZW.STATUS_FLOW.length - 1];
      return '<tr>' +
        '<td><strong>' + ZW.esc(d.id) + '</strong><br><small>' + ZW.esc(ZW.timeAgo(d.createdAt)) + '</small></td>' +
        '<td>' + ZW.esc(d.foodName) + '<br><small class="text-muted">' + ZW.esc(d.foodType) + '</small></td>' +
        '<td>' + ZW.esc(d.quantity + ' ' + d.unit) + '<br><small class="text-muted">' + ZW.esc(d.servings) + ' servings</small></td>' +
        '<td>' + ZW.statusBadge(d.status) + '<div style="margin-top:8px">' + statusFlow(d.status) + '</div></td>' +
        '<td>' + ZW.esc(ZW.deadlineText(d.pickupDeadline)) + '</td>' +
        '<td><div class="table-actions">' +
          '<button type="button" class="btn btn-success" data-advance="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-arrow-right"></i> ' + (d.status === last ? 'Completed' : 'Advance') + '</button>' +
          '<button type="button" class="btn btn-outline" data-details="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-eye"></i> View</button>' +
        '</div></td>' +
      '</tr>';
    }).join('');

    host.innerHTML = '<div class="table-wrap"><table><thead><tr>' +
      '<th>ID</th><th>Food</th><th>Quantity</th><th>Status flow</th><th>Pickup window</th><th>Actions</th>' +
      '</tr></thead><tbody>' + rows + '</tbody></table></div>';

    ZW.qsa('[data-advance]', host).forEach(function (btn) {
      btn.addEventListener('click', function () { advanceStatus(btn.getAttribute('data-advance')); });
    });
  }

  function renderReceiverTable() {
    var host = ZW.byId('dash-table');
    if (!host) return;
    var mine = myRequests().sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
    var title = ZW.byId('dash-table-title');
    if (title) title.textContent = 'Your food requests';

    if (!mine.length) {
      host.innerHTML = ZW.emptyState('No requests yet',
        'Find surplus food near you and request the servings your kitchen needs.',
        '<a class="btn btn-primary" href="receive.html"><i class="fa-solid fa-bowl-food"></i> Find food</a>');
      return;
    }

    var rows = mine.map(function (r) {
      var d = donationById(r.donationId);
      var match = d ? ZW.matchScore(d, r) + '% match' : 'donation removed';
      return '<tr>' +
        '<td><strong>' + ZW.esc(r.id) + '</strong><br><small>' + ZW.esc(ZW.timeAgo(r.createdAt)) + '</small></td>' +
        '<td>' + ZW.esc(d ? d.foodName : 'Removed donation') + '<br><small class="text-muted">' +
          ZW.esc(d ? d.donorName : '') + '</small></td>' +
        '<td>' + ZW.esc(r.servings) + '<br><small class="text-muted">servings</small></td>' +
        '<td>' + ZW.esc(match) + '</td>' +
        '<td>' + ZW.statusBadge(r.status) + '</td>' +
        '<td><div class="table-actions">' +
          (r.status !== 'Completed' ? '<button type="button" class="btn btn-success" data-complete-request="' +
            ZW.esc(r.id) + '"><i class="fa-solid fa-check"></i> Mark picked up</button>' : '') +
          (d ? '<button type="button" class="btn btn-outline" data-details="' + ZW.esc(d.id) + '">' +
            '<i class="fa-solid fa-eye"></i> View food</button>' : '') +
        '</div></td>' +
      '</tr>';
    }).join('');

    host.innerHTML = '<div class="table-wrap"><table><thead><tr>' +
      '<th>Request</th><th>Food</th><th>Servings</th><th>Smart match</th><th>Status</th><th>Actions</th>' +
      '</tr></thead><tbody>' + rows + '</tbody></table></div>';

    ZW.qsa('[data-complete-request]', host).forEach(function (btn) {
      btn.addEventListener('click', function () { completeRequest(btn.getAttribute('data-complete-request')); });
    });
  }

  function completeRequest(id) {
    var all = ZW.getRequests();
    var target = all.filter(function (r) { return r.id === id; })[0];
    if (!target) return;
    target.status = 'Completed';
    ZW.saveRequests(all);

    var donations = ZW.getDonations();
    donations.forEach(function (d) { if (d.id === target.donationId) d.status = 'Completed'; });
    ZW.saveDonations(donations);
    ZW.logActivity('Pickup completed for ' + id, 'fa-truck-fast');
    ZW.toast('Pickup completed', 'Thank you for rescuing this food!', 'success');
    refresh();
  }

  /* ----------------------------------------------------------- 5. INSIGHTS */
  function renderInsights() {
    var host = ZW.byId('dash-insights');
    if (!host) return;
    var isDonor = session.role === 'donor';
    var html = '';

    if (!isDonor) {
      /* Best matching donation for this receiver, using ZW.bestMatchFor(). */
      var pending = myRequests().filter(function (r) { return r.status !== 'Completed'; })[0];
      if (pending) {
        var best = ZW.bestMatchFor(donations, pending);
        if (best) {
          html += '<div class="card card-hover" style="border-color:var(--green-200)">' +
            '<div class="flex-between"><h3 style="margin:0;font-size:1rem">' +
            '<i class="fa-solid fa-wand-magic-sparkles text-green"></i> Smart match suggestion</h3>' +
            '<span class="badge badge-priority-high">' + best.score + '% match</span></div>' +
            '<p class="mt-2" style="font-size:0.88rem">Based on diet, servings, distance and freshness, ' +
            '<strong>' + ZW.esc(best.donation.foodName) + '</strong> from ' +
            ZW.esc(best.donation.donorName) + ' is the strongest candidate for request ' +
            ZW.esc(pending.id) + '.</p>' +
            '<button type="button" class="btn btn-primary btn-sm" data-details="' + ZW.esc(best.donation.id) + '">' +
            '<i class="fa-solid fa-circle-info"></i> View this donation</button>' +
            '<p class="mt-2" style="font-size:0.76rem;color:var(--text-soft)">Simulated recommendation - a transparent rule-based score, not a trained AI model.</p>' +
          '</div>';
        }
      }
    } else {
      var mine = myDonations();
      var urgent = mine.filter(function (d) {
        return d.status !== 'Completed' && ZW.hoursUntil(d.pickupDeadline) <= 6;
      });

      if (urgent.length) {
        html += '<div class="card" style="border-color:var(--warning)">' +
          '<h3 style="margin:0;font-size:1rem"><i class="fa-solid fa-triangle-exclamation" ' +
          'style="color:var(--warning)"></i> ' + urgent.length + ' donation(s) need attention</h3>' +
          '<p class="mt-2" style="font-size:0.88rem">Less than six hours left before the pickup deadline: ' +
          urgent.map(function (d) { return ZW.esc(d.foodName); }).join(', ') + '.</p></div>';
      }
    }

    /* Activity feed - shared by both roles. */
    var feed = ZW.getActivity().slice(0, 8);
    html += '<div class="chart-card"><div class="chart-head"><div><h3>Recent activity</h3>' +
      '<small>Everything you and the demo data have done recently</small></div>' +
      '<span class="badge badge-live"><span class="pulse-dot"></span> Live</span></div>' +
      (feed.length ? '<ul class="feed">' + feed.map(function (item) {
        return '<li><i class="fa-solid ' + ZW.esc(item.icon || 'fa-circle-check') + '"></i><div>' +
          '<strong>' + ZW.esc(item.text) + '</strong><time>' + ZW.esc(ZW.timeAgo(item.at)) + '</time></div></li>';
      }).join('') + '</ul>' : '<p style="font-size:0.86rem">No activity recorded yet.</p>') + '</div>';

    host.innerHTML = html;
  }

  /* Full record panel - every donation or request owned by this account. */
  function renderHistory() {
    var host = ZW.byId('dash-history-table');
    if (!host) return;
    var isDonor = session.role === 'donor';
    var rows = isDonor ? myDonations() : myRequests();
    if (!rows.length) {
      host.innerHTML = ZW.emptyState(
        isDonor ? 'No donations yet' : 'No requests yet',
        isDonor ? 'Your donation listings will appear here once you add one.'
                : 'Requests you make on the Receive Food page will appear here.',
        isDonor ? '<a class="btn btn-primary btn-sm" href="donate.html"><i class="fa-solid fa-hand-holding-heart"></i> Donate food</a>'
                : '<a class="btn btn-primary btn-sm" href="receive.html"><i class="fa-solid fa-bowl-food"></i> Find food</a>');
      return;
    }
    var head = isDonor
      ? '<tr><th>ID</th><th>Food</th><th>Quantity</th><th>Servings</th><th>Status</th><th>Created</th></tr>'
      : '<tr><th>ID</th><th>Donation</th><th>Servings</th><th>Pickup</th><th>Status</th><th>Requested</th></tr>';
    var body = rows.map(function (r) {
      if (isDonor) {
        return '<tr><td>' + ZW.esc(r.id) + '</td><td>' + ZW.esc(r.foodName) + '</td><td>' +
          ZW.esc(r.quantity + ' ' + r.unit) + '</td><td>' + ZW.esc(r.servings) + '</td><td>' +
          ZW.statusBadge(r.status) + '</td><td>' + ZW.esc(ZW.timeAgo(r.createdAt)) + '</td></tr>';
      }
      return '<tr><td>' + ZW.esc(r.id) + '</td><td>' + ZW.esc(r.donationId) + '</td><td>' +
        ZW.esc(r.servings) + '</td><td>' + ZW.esc(r.pickupPref) + '</td><td>' +
        ZW.statusBadge(r.status) + '</td><td>' + ZW.esc(ZW.timeAgo(r.createdAt)) + '</td></tr>';
    }).join('');
    host.innerHTML = '<div class="table-wrap"><table><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>';
  }

  /* ------------------------------------------------------------ 6. LAYOUT */
  function renderSidebar() {
    var donor = session.role === 'donor';
    var name = ZW.byId('dash-name');
    var role = ZW.byId('dash-role');
    var avatar = ZW.byId('dash-avatar');
    if (name) name.textContent = session.name;
    if (role) role.textContent = (donor ? 'Food donor' : 'Receiver / NGO') + ' - ' + (session.city || 'India');
    if (avatar) avatar.textContent = ZW.initials(session.name);
    /* Admins get a direct shortcut to the console. */
    var adminLink = ZW.byId('dash-admin-link');
    if (adminLink && session.role === 'admin') adminLink.classList.remove('hidden');
  }

  function render() {
    if (session.role === 'donor') {
      renderDonorKpis();
      renderDonorCharts();
      renderDonorTable();
    } else {
      renderReceiverKpis();
      renderReceiverCharts();
      renderReceiverTable();
    }
    renderInsights();
    renderHistory();
    ZW.wireCounters();
  }

  function refresh() {
    donations = ZW.getDonations();
    requests = ZW.getRequests();
    render();
  }

  /* Sidebar panel switching (Overview / History / Insights). */
  function wirePanelNav() {
    ZW.qsa('[data-panel]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        ZW.qsa('[data-panel]').forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        ZW.qsa('.dash-panel').forEach(function (p) { p.classList.add('hidden'); });
        var panel = ZW.byId(btn.getAttribute('data-panel'));
        if (panel) {
          panel.classList.remove('hidden');
          panel.style.animation = 'fadeUp 0.35s ease both';
        }
      });
    });
  }

  /* -------------------------------------------------------------- 7. INIT */
  function init() {
    if (!ZW.byId('dash-kpis')) return;
    session = ZW.auth.requireSession();
    if (!session) return;

    renderSidebar();
    wirePanelNav();
    var refreshBtn = ZW.byId('dash-refresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        refresh();
        ZW.toast('Dashboard refreshed', 'Figures reloaded from browser storage.', 'info', 2400);
      });
    }
    refresh();
    ZW.toast('Welcome, ' + String(session.name).split(' ')[0],
      session.role === 'donor' ? 'Track your rescues below.' : 'Here is what is available right now.', 'info', 3200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
