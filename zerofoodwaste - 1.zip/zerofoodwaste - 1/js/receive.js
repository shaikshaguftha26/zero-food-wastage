/* ==========================================================================
   ZeroWaste - receive.js
   Powers receive.html: search, filtering, sorting, dynamic cards, the
   "Request Food" modal and the receiver's request history (localStorage).
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});

  /* Tell app.js that this page owns the [data-request] buttons. */
  ZW.handlesRequest = true;

  var state = {
    search: '',
    city: '',
    category: '',
    foodType: '',
    maxKm: 0,        // 0 = no distance limit
    freshness: '',
    status: '',
    sort: 'nearest'
  };

  var currentDonationId = null;

  function value(id) {
    var el = ZW.byId(id);
    return el ? String(el.value).trim() : '';
  }

  /* --------------------------------------------------------- 1. FILTERING */
  function passesFreshness(d) {
    if (!state.freshness) return true;
    var hours = ZW.hoursUntil(d.expiryDate);
    if (state.freshness === 'fresh') return hours > 12;
    if (state.freshness === 'soon') return hours > 0 && hours <= 12;
    if (state.freshness === 'expired') return hours <= 0;
    if (state.freshness === 'unexpired') return !isNaN(hours) && hours > 0;
    return true;
  }

  function filterDonations(all) {
    var loc = ZW.getUserLocation();
    var term = state.search.toLowerCase();

    return all.filter(function (d) {
      if (state.search) {
        var haystack = [d.foodName, d.description, d.donorName, d.city, d.foodType, d.address].join(' ').toLowerCase();
        if (haystack.indexOf(term) === -1) return false;
      }
      if (state.city && d.city !== state.city) return false;
      if (state.category && d.category !== state.category) return false;
      if (state.foodType && d.foodType !== state.foodType) return false;
      if (state.status && d.status !== state.status) return false;
      if (!passesFreshness(d)) return false;
      if (state.maxKm > 0) {
        var km = ZW.distanceKm(loc, d);
        if (!isNaN(km) && km > state.maxKm) return false;
      }
      return true;
    });
  }

  function sortDonations(list) {
    var loc = ZW.getUserLocation();
    var sorted = list.slice();
    if (state.sort === 'nearest') {
      sorted.sort(function (a, b) { return ZW.distanceKm(loc, a) - ZW.distanceKm(loc, b); });
    } else if (state.sort === 'recent') {
      sorted.sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
    } else if (state.sort === 'expiring') {
      sorted.sort(function (a, b) { return new Date(a.pickupDeadline || a.expiryDate) - new Date(b.pickupDeadline || b.expiryDate); });
    } else if (state.sort === 'priority') {
      sorted.sort(function (a, b) { return ZW.priority(b, loc).score - ZW.priority(a, loc).score; });
    } else if (state.sort === 'servings') {
      sorted.sort(function (a, b) { return Number(b.servings) - Number(a.servings); });
    }
    return sorted;
  }

  /* ------------------------------------------------------------ 2. RENDER */
  function render() {
    var host = ZW.byId('receive-results');
    var summary = ZW.byId('result-summary');
    if (!host) return;

    var all = ZW.getDonations();
    var filtered = sortDonations(filterDonations(all));

    if (summary) {
      var activeCount = ['search', 'city', 'category', 'foodType', 'freshness', 'status']
        .filter(function (key) { return state[key]; }).length + (state.maxKm > 0 ? 1 : 0);
      summary.innerHTML = '<i class="fa-solid fa-bowl-food text-green"></i> Showing <strong>' +
        filtered.length + '</strong> of ' + all.length + ' donations' +
        (activeCount ? ' <span class="badge badge-neutral">' + activeCount + ' filter' +
          (activeCount > 1 ? 's' : '') + ' active</span>' : '') +
        '<button type="button" class="btn btn-ghost btn-sm" id="reset-all">Reset all</button>';
      var resetAll = ZW.byId('reset-all');
      if (resetAll) resetAll.addEventListener('click', resetFilters);
    }

    if (!filtered.length) {
      host.innerHTML = ZW.emptyState('No donations match your filters',
        'Try widening the distance, clearing the search or choosing another city. New food is listed every few minutes.',
        '<button type="button" class="btn btn-primary" id="empty-reset"><i class="fa-solid fa-rotate-left"></i> Clear all filters</button>');
      var emptyReset = ZW.byId('empty-reset');
      if (emptyReset) emptyReset.addEventListener('click', resetFilters);
      return;
    }

    host.innerHTML = '<div class="grid grid-auto">' + filtered.map(function (d) {
      return ZW.donationCard(d, { showRequest: true });
    }).join('') + '</div>';

    /* Wire the request buttons on the freshly rendered cards. */
    ZW.qsa('[data-request]', host).forEach(function (btn) {
      btn.addEventListener('click', function () { openRequest(btn.getAttribute('data-request')); });
    });
    ZW.wireReveal();
  }

  /* Brief skeleton state so the page feels like it is fetching data. */
  function renderWithLoading() {
    var host = ZW.byId('receive-results');
    if (host) host.innerHTML = ZW.skeletonCards(3);
    window.setTimeout(render, 320);
  }

  /* ------------------------------------------------------ 3. REQUEST MODAL */
  /** Opens the "Request Food" modal pre-filled for a specific donation. */
  function openRequest(donationId) {
    var donation = ZW.getDonations().filter(function (d) { return d.id === donationId; })[0];
    if (!donation) {
      ZW.toast('Donation unavailable', 'It may have just been completed or removed.', 'warn');
      render();
      return;
    }
    if (donation.status === 'Completed' || donation.status === 'Rejected') {
      ZW.toast('Not available', 'This donation is already ' + donation.status.toLowerCase() + '.', 'warn');
      return;
    }
    currentDonationId = donationId;

    var summary = ZW.byId('request-summary');
    if (summary) {
      summary.innerHTML =
        '<strong style="font-size:0.95rem">' + ZW.esc(donation.foodName) + '</strong>' +
        '<div class="flex" style="gap:8px;flex-wrap:wrap;margin:10px 0 4px">' +
          ZW.categoryBadge(donation.category) + ZW.statusBadge(donation.status) + ZW.priorityBadge(donation) +
        '</div>' +
        '<p style="margin:0;font-size:0.83rem">' + ZW.esc(donation.servings + ' servings available - ') +
          ZW.esc(donation.quantity + ' ' + donation.unit) + ' - pickup by ' +
          ZW.esc(ZW.formatDateTime(donation.pickupDeadline)) + '</p>' +
        '<p style="margin:6px 0 0;font-size:0.83rem"><i class="fa-solid fa-location-dot text-green"></i> ' +
          ZW.esc(donation.address + ', ' + donation.city) + '</p>';
    }

    var servingsInput = ZW.byId('req-servings');
    if (servingsInput) {
      servingsInput.value = '';
      servingsInput.setAttribute('max', donation.servings);
      servingsInput.setAttribute('placeholder', 'Max ' + donation.servings + ' servings');
    }

    /* Pre-fill with the signed-in receiver's details when available. */
    var session = ZW.getSession();
    if (session) {
      if (!value('req-name') && ZW.byId('req-name')) ZW.byId('req-name').value = session.name;
      if (!value('req-org') && ZW.byId('req-org')) ZW.byId('req-org').value = session.org || '';
    }
    ZW.openModal('request-modal');
  }

  function buildRequest() {
    var all = ZW.getRequests();
    var maxId = 2000;
    all.forEach(function (r) {
      var n = parseInt(String(r.id).replace(/\D/g, ''), 10);
      if (!isNaN(n) && n > maxId) maxId = n;
    });
    return {
      id: 'ZWR-' + (maxId + 1),
      donationId: currentDonationId,
      receiverName: value('req-name'),
      orgName: value('req-org'),
      phone: value('req-phone'),
      servings: parseInt(value('req-servings'), 10) || 0,
      pickupPref: value('req-pref') || 'Own vehicle',
      note: value('req-note'),
      status: 'Pending',
      createdAt: new Date().toISOString()
    };
  }

  function wireRequestForm() {
    var form = ZW.byId('request-form');
    if (!form) return;
    ZW.forms.wireLiveValidation(form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      ZW.forms.banner('request-alert', null);
      if (!ZW.forms.validate(form).ok) return;

      var donation = ZW.getDonations().filter(function (d) { return d.id === currentDonationId; })[0];
      if (!donation) {
        ZW.closeModal('request-modal');
        ZW.toast('Donation unavailable', 'Please choose another donation.', 'warn');
        render();
        return;
      }
      var wanted = parseInt(value('req-servings'), 10) || 0;
      if (wanted > donation.servings) {
        ZW.forms.banner('request-alert', { title: 'Too many servings requested',
          text: 'Only ' + donation.servings + ' servings are available for this donation.' }, 'error');
        return;
      }

      var submit = form.querySelector('button[type="submit"]');
      submit.classList.add('is-loading');

      window.setTimeout(function () {
        submit.classList.remove('is-loading');
        var request = buildRequest();
        var requests = ZW.getRequests();
        requests.push(request);
        ZW.saveRequests(requests);

        /* The donation stays Pending: the donor (or an admin) accepts it. */
        ZW.logActivity('Request ' + request.id + ' placed for ' + donation.foodName, 'fa-hand-holding-heart');
        ZW.toast('Request confirmed', request.id + ' has been sent to ' + donation.donorName + '.', 'success', 6000);
        ZW.forms.banner('request-alert', { title: 'Request ' + request.id + ' confirmed',
          text: 'The donor will see your request in their dashboard. You will be notified when the pickup is scheduled.' }, 'success');
        form.reset();
        ZW.closeModal('request-modal');
        renderMyRequests();
        renderWithLoading();
      }, 600);
    });
  }

  /* ---------------------------------------------- 4. MY REQUESTS (RECEIVER) */
  function renderMyRequests() {
    var host = ZW.byId('my-requests');
    if (!host) return;
    var donations = ZW.getDonations();
    var requests = ZW.getRequests().slice().sort(function (a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    });

    if (!requests.length) {
      host.innerHTML = ZW.emptyState('You have not requested food yet',
        'Browse the listings above and request the servings your kitchen needs.',
        '');
      return;
    }

    var rows = requests.map(function (r) {
      var d = donations.filter(function (x) { return x.id === r.donationId; })[0] || null;
      var match = d ? '<span class="badge badge-neutral"><i class="fa-solid fa-wand-magic-sparkles"></i> ' +
        ZW.matchScore(d, r) + '% match</span>' : '<span class="badge badge-neutral">Donation removed</span>';
      return '<tr>' +
        '<td><strong>' + ZW.esc(r.id) + '</strong><br><small>' + ZW.esc(ZW.timeAgo(r.createdAt)) + '</small></td>' +
        '<td>' + ZW.esc(d.foodName || 'Removed donation') + '<br><small class="text-muted">' +
          ZW.esc(d.donorName || '') + '</small></td>' +
        '<td>' + ZW.esc(r.orgName) + '<br><small class="text-muted">' + ZW.esc(r.phone) + '</small></td>' +
        '<td>' + ZW.esc(r.servings) + '</td>' +
        '<td>' + match + '</td>' +
        '<td>' + ZW.statusBadge(r.status) + '</td>' +
        '<td>' + ZW.esc(r.pickupPref) + '</td>' +
      '</tr>';
    }).join('');

    host.innerHTML = '<div class="table-wrap"><table><thead><tr>' +
      '<th>Request</th><th>Food</th><th>Requested by</th><th>Servings</th>' +
      '<th>Smart match</th><th>Status</th><th>Pickup</th>' +
      '</tr></thead><tbody>' + rows + '</tbody></table></div>';
  }

  /* ------------------------------------------------------- 5. FILTER WIRING */
  var BOUND = [
    ['receive-search', 'search'],
    ['filter-city', 'city'],
    ['filter-category', 'category'],
    ['filter-type', 'foodType'],
    ['filter-freshness', 'freshness'],
    ['filter-status', 'status'],
    ['sort-by', 'sort']
  ];

  function wireFilters() {
    BOUND.forEach(function (pair) {
      var el = ZW.byId(pair[0]);
      if (!el) return;
      if (el.tagName === 'SELECT') {
        el.addEventListener('change', function () {
          state[pair[1]] = el.value;
          renderWithLoading();
        });
      } else {
        /* Text inputs feed the debounced search handler below. */
        el.addEventListener('input', function () { state[pair[1]] = el.value; });
      }
    });

    /* Debounce the search box so cards do not re-render on every keystroke. */
    var search = ZW.byId('receive-search');
    if (search) {
      var timer = null;
      search.addEventListener('input', function () {
        window.clearTimeout(timer);
        timer = window.setTimeout(function () {
          state.search = search.value.trim();
          renderWithLoading();
        }, 260);
      });
    }

    /* Distance slider with a live label ("Any distance" / "within 12 km"). */
    var distance = ZW.byId('filter-distance');
    var distanceLabel = ZW.byId('filter-distance-value');
    if (distance) {
      distance.addEventListener('input', function () {
        state.maxKm = parseFloat(distance.value) || 0;
        if (distanceLabel) {
          distanceLabel.textContent = state.maxKm > 0 ? 'within ' + state.maxKm + ' km' : 'Any distance';
        }
      });
      distance.addEventListener('change', renderWithLoading);
    }

    /* Quick category chips above the results grid. */
    ZW.qsa('.chip[data-chip-category]').forEach(function (chip) {
      chip.addEventListener('click', function () {
        var pick = chip.getAttribute('data-chip-category');
        var next = state.category === pick ? '' : pick;
        state.category = next;
        ZW.qsa('.chip[data-chip-category]').forEach(function (c) {
          c.classList.toggle('is-active', c.getAttribute('data-chip-category') === next);
        });
        var select = ZW.byId('filter-category');
        if (select) select.value = next;
        renderWithLoading();
      });
    });

    /* "Use my location" - the demo stores the chosen city as the user pin. */
    var locSelect = ZW.byId('user-location');
    if (locSelect) {
      var saved = ZW.getUserLocation();
      ZW.qsa('option', locSelect).forEach(function (o) {
        if (o.value === saved.label) locSelect.value = o.value;
      });
      locSelect.addEventListener('change', function () {
        var coords = {
          'Hyderabad, Telangana': { lat: 17.3850, lng: 78.4867 },
          'Bengaluru, Karnataka': { lat: 12.9716, lng: 77.5946 },
          'Mumbai, Maharashtra': { lat: 19.0760, lng: 72.8777 },
          'Delhi NCR': { lat: 28.6139, lng: 77.2090 },
          'Chennai, Tamil Nadu': { lat: 13.0827, lng: 80.2707 },
          'Pune, Maharashtra': { lat: 18.5204, lng: 73.8567 }
        };
        var c = coords[locSelect.value] || ZW.DEFAULT_LOCATION;
        ZW.saveUserLocation({ label: locSelect.value, lat: c.lat, lng: c.lng });
        ZW.toast('Location updated', 'Distances are now measured from ' + locSelect.value + '.', 'info');
        renderWithLoading();
      });
    }
  }

  function resetFilters() {
    state.search = '';
    state.city = '';
    state.category = '';
    state.foodType = '';
    state.freshness = '';
    state.status = '';
    state.maxKm = 0;
    state.sort = 'nearest';
    ZW.qsa('#receive-search, #filter-city, #filter-category, #filter-type, #filter-freshness, #filter-status, #sort-by')
      .forEach(function (el) { el.value = ''; });
    var sort = ZW.byId('sort-by');
    if (sort) sort.value = 'nearest';
    var distance = ZW.byId('filter-distance');
    if (distance) distance.value = 0;
    var label = ZW.byId('filter-distance-value');
    if (label) label.textContent = 'Any distance';
    ZW.qsa('.chip[data-chip-category]').forEach(function (c) { c.classList.remove('is-active'); });
    ZW.toast('Filters cleared', 'Showing every available donation again.', 'info', 2400);
    renderWithLoading();
  }

  /* --------------------------------------------------------- 6. DEEP LINKS */
  /* index.html / donot cards link to receive.html?id=ZWD-1004 */
  function handleDeepLink() {
    var id = new URLSearchParams(window.location.search).get('id');
    if (!id) return;
    window.setTimeout(function () { openRequest(id); }, 700);
  }

  /* -------------------------------------------------------------- 7. INIT */
  function init() {
    if (!ZW.byId('receive-results')) return;
    wireFilters();
    wireRequestForm();
    renderMyRequests();
    renderWithLoading();
    handleDeepLink();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
