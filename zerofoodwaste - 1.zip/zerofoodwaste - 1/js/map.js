/* ==========================================================================
   ZeroWaste - map.js
   Food Map page. Uses Leaflet + OpenStreetMap tiles from a CDN when they are
   reachable and falls back to a hand-built CSS map when they are not, so the
   page still works completely offline. Frontend only - no backend calls.
   ========================================================================== */
(function () {
  'use strict';
  var ZW = (window.ZW = window.ZW || {});

  var state = { search: '', foodType: '', city: '', maxKm: 0, minPriority: '' };
  var map = null;
  var markers = {};

  /* Fixed India bounds keep the CSS fallback pins stable between filters. */
  var BOUNDS = { minLat: 8, maxLat: 35, minLng: 68, maxLng: 98 };

  function filtered() {
    var loc = ZW.getUserLocation();
    var term = state.search.toLowerCase();
    return ZW.getDonations().filter(function (d) {
      if (state.search) {
        var hay = [d.city, d.address, d.foodName, d.donorName].join(' ').toLowerCase();
        if (hay.indexOf(term) === -1) return false;
      }
      if (state.foodType && d.foodType !== state.foodType) return false;
      if (state.city && d.city !== state.city) return false;
      if (state.minPriority && ZW.priority(d, loc).level !== state.minPriority) return false;
      if (state.maxKm > 0) {
        var km = ZW.distanceKm(loc, d);
        if (!isNaN(km) && km > state.maxKm) return false;
      }
      return true;
    });
  }

  function pinClass(d) {
    var level = ZW.priority(d).level;
    return level === 'High' ? 'pin-high' : level === 'Medium' ? 'pin-medium' : '';
  }

  function popupHtml(d) {
    var km = ZW.distanceKm(ZW.getUserLocation(), d);
    return '<h4>' + ZW.esc(d.foodName) + '</h4>' +
      '<div style="font-size:0.8rem;line-height:1.7">' +
      '<div><strong>' + ZW.esc(d.quantity + ' ' + d.unit) + '</strong> - ' + ZW.esc(d.servings) + ' servings</div>' +
      '<div>' + ZW.esc(d.foodType) + ' - ' + ZW.esc(ZW.CATEGORY_LABEL[d.category] || d.category) + '</div>' +
      '<div>' + ZW.esc(d.city) + (isNaN(km) ? '' : ' - ' + km + ' km away') + '</div>' +
      '<div>Pickup: ' + ZW.esc(ZW.deadlineText(d.pickupDeadline)) + '</div>' +
      '<div style="margin:6px 0">' + ZW.statusBadge(d.status) + ' ' + ZW.priorityBadge(d) + '</div>' +
      '<button type="button" class="btn btn-primary btn-sm" data-details="' + ZW.esc(d.id) + '">' +
      '<i class="fa-solid fa-circle-info"></i> View Details</button>' +
      '</div>';
  }

  /* ---------------------------------------------------- 1. LEAFLET PATH */
  function initLeaflet() {
    var loc = ZW.getUserLocation();
    map = window.L.map('leaflet-map', { scrollWheelZoom: true, zoomControl: true })
      .setView([loc.lat, loc.lng], 11);

    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    window.L.circleMarker([loc.lat, loc.lng], {
      radius: 8, color: '#16a34a', fillColor: '#22c55e', fillOpacity: 0.9, weight: 3
    }).addTo(map).bindPopup('<strong>You are here</strong><br>' + ZW.esc(loc.label));
  }

  function renderLeaflet(list) {
    /* Remove markers that are no longer in the filtered list. */
    Object.keys(markers).forEach(function (id) {
      if (!list.some(function (d) { return d.id === id; })) {
        map.removeLayer(markers[id]);
        delete markers[id];
      }
    });

    list.forEach(function (d) {
      if (markers[d.id]) { markers[d.id].setPopupContent(popupHtml(d)); return; }
      var icon = window.L.divIcon({
        className: '',
        html: '<div class="custom-pin ' + pinClass(d) + '"><i class="fa-solid fa-utensils"></i></div>',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -28]
      });
      markers[d.id] = window.L.marker([d.lat, d.lng], { icon: icon, title: d.foodName })
        .addTo(map).bindPopup(popupHtml(d));
    });
  }

  /* ------------------------------------------------- 2. CSS FALLBACK PATH */
  function projectPosition(d) {
    var x = ((d.lng - BOUNDS.minLng) / (BOUNDS.maxLng - BOUNDS.minLng)) * 100;
    var y = ((BOUNDS.maxLat - d.lat) / (BOUNDS.maxLat - BOUNDS.minLat)) * 100;
    return { x: Math.max(3, Math.min(95, x)), y: Math.max(4, Math.min(94, y)) };
  }

  var fallbackPins = {};

  function renderFallback(list) {
    var host = ZW.byId('map-fallback');
    if (!host) return;
    Object.keys(fallbackPins).forEach(function (id) {
      if (!list.some(function (d) { return d.id === id; })) {
        if (fallbackPins[id].parentNode) fallbackPins[id].parentNode.removeChild(fallbackPins[id]);
        delete fallbackPins[id];
      }
    });

    list.forEach(function (d) {
      var pos = projectPosition(d);
      var pin = fallbackPins[d.id];
      if (!pin) {
        pin = document.createElement('button');
        pin.type = 'button';
        pin.className = 'pin ' + pinClass(d);
        pin.setAttribute('data-details', d.id);
        pin.setAttribute('aria-label', 'Show details for ' + d.foodName);
        pin.innerHTML = '<i class="fa-solid fa-utensils"></i>';
        host.appendChild(pin);
        fallbackPins[d.id] = pin;
      }
      pin.style.left = pos.x + '%';
      pin.style.top = pos.y + '%';
      pin.title = d.foodName + ' - ' + d.quantity + ' ' + d.unit + ' - ' + ZW.deadlineText(d.pickupDeadline);
    });
  }

  /* --------------------------------------------------------- 3. SIDE LIST */
  function renderList(list) {
    var host = ZW.byId('map-list');
    if (!host) return;
    if (!list.length) {
      host.innerHTML = ZW.emptyState('No donations on the map',
        'No donation matches the current search or filters. Try a wider distance.',
        '<button type="button" class="btn btn-primary" id="map-reset"><i class="fa-solid fa-rotate-left"></i> Reset filters</button>');
      var reset = ZW.byId('map-reset');
      if (reset) reset.addEventListener('click', resetFilters);
      return;
    }

    var loc = ZW.getUserLocation();
    host.innerHTML = list.map(function (d) {
      var km = ZW.distanceKm(loc, d);
      return '<article class="map-item" data-focus="' + ZW.esc(d.id) + '">' +
        '<h4>' + ZW.esc(d.foodName) + ' ' + ZW.statusBadge(d.status) + '</h4>' +
        '<div class="meta">' +
          '<span><i class="fa-solid fa-utensils"></i>' + ZW.esc(d.foodType) + '</span>' +
          '<span><i class="fa-solid fa-box-open"></i>' + ZW.esc(d.quantity + ' ' + d.unit) + '</span>' +
          '<span><i class="fa-solid fa-location-dot"></i>' + ZW.esc(d.city) + (isNaN(km) ? '' : ' - ' + km + ' km') + '</span>' +
          '<span><i class="fa-regular fa-clock"></i>' + ZW.esc(ZW.deadlineText(d.pickupDeadline)) + '</span>' +
        '</div>' +
        '<div class="flex-between" style="margin-top:12px">' + ZW.priorityBadge(d) +
          '<button type="button" class="btn btn-outline btn-sm" data-details="' + ZW.esc(d.id) + '">' +
          '<i class="fa-solid fa-circle-info"></i> View Details</button>' +
        '</div>' +
      '</article>';
    }).join('');

    ZW.qsa('[data-focus]', host).forEach(function (item) {
      item.addEventListener('click', function (e) {
        if (e.target.closest('[data-details]')) return; // let the details button win
        focusDonation(item.getAttribute('data-focus'));
      });
    });
  }

  /** Highlights a donation: pans the Leaflet map or pulses the CSS pin. */
  function focusDonation(id) {
    var donation = ZW.getDonations().filter(function (d) { return d.id === id; })[0];
    if (!donation) return;
    ZW.qsa('.map-item').forEach(function (el) {
      el.classList.toggle('is-active', el.getAttribute('data-focus') === id);
    });
    if (map && markers[id]) {
      map.setView([donation.lat, donation.lng], 13, { animate: true });
      markers[id].openPopup();
    } else if (fallbackPins[id]) {
      fallbackPins[id].classList.add('is-active');
      var item = document.querySelector('.map-item[data-focus="' + id + '"]');
      if (item && item.scrollIntoView) item.scrollIntoView({ block: 'nearest' });
    }
  }

  /* ---------------------------------------------------------- 4. STATS */
  function renderStats(list) {
    var loc = ZW.getUserLocation();
    var high = list.filter(function (d) { return ZW.priority(d, loc).level === 'High'; }).length;
    var meals = list.reduce(function (sum, d) { return sum + (Number(d.servings) || 0); }, 0);
    var cities = {};
    list.forEach(function (d) { cities[d.city] = true; });
    var set = function (id, text) {
      var el = ZW.byId(id);
      if (el) el.textContent = text;
    };
    set('map-stat-count', list.length);
    set('map-stat-high', high);
    set('map-stat-meals', meals);
    set('map-stat-cities', Object.keys(cities).length);
    set('map-result-count', list.length + (list.length === 1 ? ' donation' : ' donations') + ' plotted');
  }

  function renderAll() {
    var list = filtered();
    if (map) renderLeaflet(list); else renderFallback(list);
    renderList(list);
    renderStats(list);
  }

  /* ------------------------------------------------------ 5. FILTER WIRING */
  function wireFilters() {
    var search = ZW.byId('map-search');
    if (search) {
      var timer = null;
      search.addEventListener('input', function () {
        window.clearTimeout(timer);
        timer = window.setTimeout(function () {
          state.search = search.value.trim();
          renderAll();
        }, 250);
      });
    }

    [['map-filter-type', 'foodType'], ['map-filter-city', 'city'], ['map-filter-priority', 'minPriority']]
      .forEach(function (pair) {
        var el = ZW.byId(pair[0]);
        if (!el) return;
        el.addEventListener('change', function () {
          state[pair[1]] = el.value;
          renderAll();
        });
      });

    var distance = ZW.byId('map-filter-distance');
    var label = ZW.byId('map-distance-value');
    if (distance) {
      distance.addEventListener('input', function () {
        state.maxKm = parseFloat(distance.value) || 0;
        if (label) label.textContent = state.maxKm > 0 ? 'within ' + state.maxKm + ' km' : 'Any distance';
      });
      distance.addEventListener('change', renderAll);
    }

    var recenter = ZW.byId('map-recenter');
    if (recenter) {
      recenter.addEventListener('click', function () {
        var loc = ZW.getUserLocation();
        if (map) map.setView([loc.lat, loc.lng], 11, { animate: true });
        else ZW.toast('Map centred', 'Your demo location is ' + loc.label + '.', 'info');
      });
    }
    var reset = ZW.byId('map-clear');
    if (reset) reset.addEventListener('click', resetFilters);
    var locateBtn = ZW.byId('map-use-location');
    if (locateBtn) {
      locateBtn.addEventListener('click', function () {
        var loc = ZW.getUserLocation();
        ZW.toast('Using demo location', 'Distances are measured from ' + loc.label + '. Real GPS is not used in this demo.', 'info', 5000);
        renderAll();
      });
    }
  }

  function resetFilters() {
    state.search = '';
    state.foodType = '';
    state.city = '';
    state.minPriority = '';
    state.maxKm = 0;
    ZW.qsa('#map-search, #map-filter-type, #map-filter-city, #map-filter-priority')
      .forEach(function (el) { el.value = ''; });
    var distance = ZW.byId('map-filter-distance');
    if (distance) distance.value = 0;
    var label = ZW.byId('map-distance-value');
    if (label) label.textContent = 'Any distance';
    ZW.toast('Filters cleared', 'Showing every donation on the map.', 'info', 2400);
    renderAll();
  }

  /* -------------------------------------------------------------- 6. INIT */
  function init() {
    if (!ZW.byId('map-canvas')) return;
    wireFilters();

    /* Leaflet arrives from a CDN. If it is missing (offline demo) we keep the
       hand-built CSS map instead, so the page never breaks. */
    var leafletHost = ZW.byId('leaflet-map');
    if (window.L && leafletHost) {
      var fallback = ZW.byId('map-fallback');
      leafletHost.classList.remove('hidden');
      if (fallback) fallback.classList.add('hidden');
      initLeaflet();
      var badge = ZW.byId('map-mode-badge');
      if (badge) badge.textContent = 'Live OpenStreetMap tiles';
    } else {
      var note = ZW.byId('map-offline-note');
      if (note) note.classList.remove('hidden');
      ZW.toast('Offline map mode', 'Leaflet could not load, so the built-in map is used.', 'info', 6000);
    }
    renderAll();
    window.addEventListener('resize', function () { if (map) map.invalidateSize(); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
